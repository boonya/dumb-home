function module(e,n,t){var u,l,o;function a(e){return l.createElement(o,u({preload:"none",autoPlay:!0,type:"video/mp4"},e))}t.link("@babel/runtime/helpers/extends",{default:function(e){u=e}},0),t.export({default:function(){return a}}),t.link("react",{default:function(e){l=e}},0),t.link(".",{default:function(e){o=e}},1)}

