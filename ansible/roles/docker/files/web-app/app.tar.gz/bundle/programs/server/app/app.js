var require = meteorInstall({"imports":{"ui":{"components":{"Preloader.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/ui/components/Preloader.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let PropTypes;
module.link("prop-types", {
  default(v) {
    PropTypes = v;
  }

}, 0);
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 1);
let withStyles;
module.link("@material-ui/core", {
  withStyles(v) {
    withStyles = v;
  }

}, 2);
let yellow;
module.link("@material-ui/core/colors", {
  yellow(v) {
    yellow = v;
  }

}, 3);

const Preloader = (_ref) => {
  let {
    classes
  } = _ref;
  return /*#__PURE__*/React.createElement("div", {
    className: classes.overlay
  }, /*#__PURE__*/React.createElement("div", {
    className: classes.circular
  }, " "));
};

Preloader.propTypes = {
  classes: PropTypes.objectOf(PropTypes.string).isRequired
};
module.exportDefault(withStyles(theme => ({
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    zIndex: 1100,
    backgroundColor: 'rgba(48, 48, 48, .7)',
    transition: '0.5s linear all'
  },
  circular: {
    display: 'block',
    position: 'relative',
    left: '50%',
    top: '50%',
    width: 100,
    height: 100,
    margin: '-75px 0 0 -75px',
    borderRadius: '50%',
    border: '3px solid transparent',
    animation: '$spin 2s linear infinite',
    borderTopColor: theme.palette.primary.main,
    '&:before': {
      content: '""',
      position: 'absolute',
      borderRadius: '50%',
      border: '3px solid transparent',
      animation: '$spin 3s linear infinite',
      borderTopColor: theme.palette.secondary.main,
      top: 5,
      left: 5,
      right: 5,
      bottom: 5
    },
    '&:after': {
      content: '""',
      position: 'absolute',
      borderRadius: '50%',
      border: '3px solid transparent',
      animation: '$spin 1.5s linear infinite',
      borderTopColor: yellow.A400,
      top: 15,
      left: 15,
      right: 15,
      bottom: 15
    }
  },
  '@keyframes spin': {
    '0%': {
      transform: 'rotate(0deg)'
    },
    '100%': {
      transform: 'rotate(360deg)'
    }
  }
}))(Preloader));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"theme.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/ui/theme.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let deepOrange, indigo;
module.link("@material-ui/core/colors", {
  deepOrange(v) {
    deepOrange = v;
  },

  indigo(v) {
    indigo = v;
  }

}, 0);
let createMuiTheme;
module.link("@material-ui/core/styles", {
  createMuiTheme(v) {
    createMuiTheme = v;
  }

}, 1);
const theme = createMuiTheme({
  palette: {
    primary: indigo,
    secondary: deepOrange,
    type: 'dark'
  },
  typography: {
    fontFamily: 'Roboto',
    fontSize: 14,
    fontWeight: 300,
    h1: {
      fontSize: '3.5rem'
    },
    h2: {
      fontSize: '3rem'
    },
    h3: {
      fontSize: '2.5rem'
    },
    h4: {
      fontSize: '2rem'
    },
    h5: {
      fontSize: '1.5rem'
    },
    h6: {
      fontSize: '1rem'
    }
  }
});
module.exportDefault(theme);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"api":{"camera.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/camera.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Devices;
module.link("../collections/devices", {
  default(v) {
    Devices = v;
  }

}, 1);
let METHODS;
module.link("../methods", {
  default(v) {
    METHODS = v;
  }

}, 2);
let DEVICES;
module.link("../devices", {
  default(v) {
    DEVICES = v;
  }

}, 3);

const discover = () => new Promise((resolve, reject) => {
  try {
    Meteor.call(METHODS.DISCOVER_CAMERA, (err, response) => {
      if (err) return reject(err);
      resolve(response);
    });
  } catch (error) {
    reject(error);
  }
});

const add = params => Promise.asyncApply(() => {
  const {
    hostname,
    port
  } = params.details;
  return Devices.insert(_objectSpread({}, params, {
    details: {
      hostname,
      port
    },
    type: DEVICES.CAMERA,
    owner: Meteor.userId()
  }));
});

const edit = (_ref) => Promise.asyncApply(() => {
  let {
    _id,
    label,
    username,
    password
  } = _ref;
  return Devices.update({
    _id
  }, {
    $set: {
      label,
      username,
      password
    }
  });
}); // const startRecord = (id, name, uri) => new Promise((resolve, reject) => {
//   Meteor.call(METHODS.CAMERA_RECORD_START, { id, name, uri }, (err, response) => {
//     if (err) return reject(err);
//     // Devices.update({ _id: id }, { $set: { recording: true } });
//     resolve(response);
//   });
// });
// const stopRecord = (id) => new Promise((resolve, reject) => {
//   Meteor.call(METHODS.CAMERA_RECORD_STOP, { id }, (err, response) => {
//     if (err) return reject(err);
//     // Devices.update({ _id: id }, { $set: { recording: false } });
//     resolve(response);
//   });
// });


const getStreamUri = (hostname, port, username, password) => new Promise((resolve, reject) => {
  Meteor.call(METHODS.CAMERA_GET_STREAM_URI, {
    hostname,
    port,
    username,
    password
  }, (err, uri) => {
    if (err) return reject(err);
    resolve(uri);
  });
});

const startRecord = id => Promise.asyncApply(() => {
  const {
    label,
    details,
    username,
    password
  } = Devices.findOne({
    _id: id
  });
  const {
    hostname,
    port
  } = details;
  const uri = Promise.await(getStreamUri(hostname, port, username, password)); // await startRecord(id, label, uri);

  return new Promise((resolve, reject) => {
    Meteor.call(METHODS.CAMERA_RECORD_START, {
      id,
      name: label,
      uri
    }, (err, response) => {
      if (err) return reject(err);
      resolve(response);
    });
  });
});

const stopRecord = id => new Promise((resolve, reject) => {
  Meteor.call(METHODS.CAMERA_RECORD_STOP, {
    id
  }, (err, response) => {
    if (err) return reject(err);
    resolve(response);
  });
});

module.exportDefault({
  discover,
  add,
  edit,
  getStreamUri,
  startRecord,
  stopRecord
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"devices.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/devices.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Devices;
module.link("../collections/devices", {
  default(v) {
    Devices = v;
  }

}, 0);
let ObservableCollection;
module.link("../utils", {
  ObservableCollection(v) {
    ObservableCollection = v;
  }

}, 1);

const find = function () {
  return Devices.find(...arguments);
};

const fetch = function () {
  return find(...arguments).fetch();
};

const findOne = function () {
  return Promise.asyncApply(() => {
    return Devices.findOne(...arguments);
  });
};

const insert = function () {
  return Promise.asyncApply(() => {
    return Devices.insert(...arguments);
  });
};

const remove = function () {
  return Promise.asyncApply(() => {
    return Devices.remove(...arguments);
  });
};

const observableDevice = ObservableCollection(findOne);
module.exportDefault({
  find,
  fetch,
  findOne,
  insert,
  remove,
  observableDevice
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"devices.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections/devices.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
module.exportDefault(new Mongo.Collection('devices'));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"accounts.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/accounts.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let MeteorAccounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    MeteorAccounts = v;
  }

}, 1);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SUPERUSER;
module.link("../env", {
  SUPERUSER(v) {
    SUPERUSER = v;
  }

}, 3);
module.exportDefault({
  onCreateHook() {
    MeteorAccounts.onCreateUser((options, user) => {
      const roles = ['user'];
      if (options.role === 'admin') roles.push('admin');
      Roles.addUsersToRoles(user._id, roles, Roles.GLOBAL_GROUP);
    });
  },

  createSuperUser() {
    if (!SUPERUSER.NAME || !SUPERUSER.EMAIL || !SUPERUSER.PASSWORD) {
      console.info('SUPERUSER env. vars is not defined. Skip.');
      return;
    }

    if (Meteor.users.find().count()) {
      console.info('Users collection already exists. Skip.');
      return;
    }

    const userId = MeteorAccounts.createUser({
      username: SUPERUSER.NAME,
      email: SUPERUSER.EMAIL,
      password: SUPERUSER.PASSWORD
    });
    Roles.addUsersToRoles(userId, ['user', 'superuser'], Roles.GLOBAL_GROUP);
    console.info('Superuser account created: ', {
      id: userId,
      username: SUPERUSER.NAME,
      email: SUPERUSER.EMAIL
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"camera.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/camera.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let ffmpeg;
module.link("fluent-ffmpeg", {
  default(v) {
    ffmpeg = v;
  }

}, 0);
let Discovery, Cam;
module.link("onvif", {
  Discovery(v) {
    Discovery = v;
  },

  Cam(v) {
    Cam = v;
  }

}, 1);
let Devices;
module.link("../api/devices", {
  default(v) {
    Devices = v;
  }

}, 2);

const discover = () => new Promise((resolve, reject) => {
  try {
    Discovery.probe((err, cams) => {
      if (err) throw new Error(err);
      resolve(cams);
    });
  } catch (error) {
    reject(error);
  }
});

const getStreamUri = (_ref) => {
  let {
    hostname,
    port,
    username,
    password = ''
  } = _ref;
  return new Promise((resolve, reject) => {
    try {
      // eslint-disable-next-line no-new
      new Cam({
        hostname,
        port,
        username,
        password
      }, function (err) {
        if (err) throw new Error(err); // eslint-disable-next-line no-shadow

        this.getStreamUri({
          protocol: 'RTSP'
        }, (err, stream) => {
          if (err) throw new Error(err);
          resolve(stream.uri);
        });
      });
    } catch (error) {
      reject(error);
    }
  });
};

const getStream = source => ffmpeg(source, {
  logger: console
}).noAudio().videoCodec('copy').toFormat('mp4').outputOptions(['-rtsp_transport', 'tcp', '-movflags', 'frag_keyframe+empty_moov', '-reset_timestamps', '1', '-vsync', '1', '-flags', 'global_header', '-bsf:v', 'dump_extra']);

const handleStream = _id => Promise.asyncApply(() => {
  const {
    details,
    username,
    password
  } = Promise.await(Devices.findOne({
    _id
  }));
  const {
    hostname,
    port
  } = details;
  const streamUri = Promise.await(getStreamUri({
    hostname,
    port,
    username,
    password
  }));
  return getStream(streamUri);
});

module.exportDefault({
  discover,
  getStreamUri,
  handleStream
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/methods.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let METHODS;
module.link("../methods", {
  default(v) {
    METHODS = v;
  }

}, 0);
let Camera;
module.link("./camera", {
  default(v) {
    Camera = v;
  }

}, 1);
let Recorder;
module.link("./recorder", {
  default(v) {
    Recorder = v;
  }

}, 2);
module.exportDefault({
  [METHODS.DISCOVER_CAMERA]: Camera.discover,
  [METHODS.CAMERA_GET_STREAM_URI]: Camera.getStreamUri,
  [METHODS.CAMERA_RECORD_START]: Recorder.start,
  [METHODS.CAMERA_RECORD_STOP]: Recorder.stop
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/publish.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Devices;
module.link("../collections/devices", {
  default(v) {
    Devices = v;
  }

}, 1);
module.exportDefault(() => {
  Meteor.publish('devices', function () {
    return Devices.find(...arguments);
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"recorder.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/recorder.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let RtspRecorder, RecorderEvents;
module.link("rtsp-video-recorder", {
  default(v) {
    RtspRecorder = v;
  },

  RecorderEvents(v) {
    RecorderEvents = v;
  }

}, 0);
let RECORDER;
module.link("../config", {
  RECORDER(v) {
    RECORDER = v;
  }

}, 1);
let DEVICES;
module.link("../devices", {
  default(v) {
    DEVICES = v;
  }

}, 2);
let Devices;
module.link("../collections/devices", {
  default(v) {
    Devices = v;
  }

}, 3);
let api;
module.link("../api/camera", {
  default(v) {
    api = v;
  }

}, 4);

class Recorder {
  constructor() {
    this.Registry = {};

    this.getRecorderInstance = (id, uri, name) => {
      const {
        FOLDER,
        SEGMENT_TIME,
        DIR_SIZE_THRESHOLD,
        AUTO_CLEAR
      } = RECORDER;
      const recorder = new RtspRecorder(uri, FOLDER, {
        title: name,
        filenamePattern: "%H.%M.%S-".concat(name.replace(/%/g, '%%')),
        segmentTime: SEGMENT_TIME,
        dirSizeThreshold: DIR_SIZE_THRESHOLD,
        autoClear: AUTO_CLEAR
      });
      recorder.on(RecorderEvents.STARTED, function () {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.STARTED, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.STOPPED, function () {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.STOPPED, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.STOP, function () {
        for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          args[_key3] = arguments[_key3];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.STOP, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.PROGRESS, buffer => {
        const payload = buffer.toString(); // frame=  638 fps= 21 q=-1.0 size=N/A time=00:00:31.85 bitrate=N/A speed=1.04x
        // [rtsp @ 0x7f82a8800000] max delay reached.
        // [rtsp @ 0x7f82a8800000] RTP: missed 101 packets

        if (/^\s*\[rtsp @ 0x[0-9a-f]+\] max delay reached/.test(payload) || /^\s*\[rtsp @ 0x[0-9a-f]+\] RTP: missed/.test(payload) || /^\s*frame=/.test(payload)) {
          return;
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.PROGRESS, "; \"").concat(name, "\": "), payload);
      });
      recorder.on(RecorderEvents.ERROR, function () {
        for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
          args[_key4] = arguments[_key4];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.ERROR, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.SEGMENT_STARTED, function () {
        for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
          args[_key5] = arguments[_key5];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.SEGMENT_STARTED, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.DIRECTORY_CREATED, function () {
        for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
          args[_key6] = arguments[_key6];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.DIRECTORY_CREATED, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.FILE_CREATED, function () {
        for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
          args[_key7] = arguments[_key7];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.FILE_CREATED, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.SPACE_FULL, function () {
        for (var _len8 = arguments.length, args = new Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
          args[_key8] = arguments[_key8];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.SPACE_FULL, "; \"").concat(name, "\": "), ...args);
      });
      recorder.on(RecorderEvents.SPACE_WIPED, function () {
        for (var _len9 = arguments.length, args = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
          args[_key9] = arguments[_key9];
        }

        console.log(" ".concat(new Date(), "; ").concat(RecorderEvents.SPACE_WIPED, "; \"").concat(name, "\": "), ...args);
      });
      return recorder;
    };

    this.start = (_ref) => {
      let {
        id,
        name,
        uri
      } = _ref;
      const recorder = this.getRecorderInstance(id, uri, name);
      recorder.on('stopped', Meteor.bindEnvironment(() => {
        Devices.update({
          _id: id
        }, {
          $set: {
            recording: false
          }
        });
      })).start();
      Devices.update({
        _id: id
      }, {
        $set: {
          recording: true
        }
      });
      this.Registry[id] = recorder;
    };

    this.stop = (_ref2) => {
      let {
        id
      } = _ref2;
      const recorder = this.Registry[id];

      if (recorder) {
        recorder.stop();
      }

      Devices.update({
        _id: id
      }, {
        $set: {
          recording: false
        }
      });
    };

    this.startup = () => {
      const promises = Devices.find({
        type: DEVICES.CAMERA,
        recording: true
      }).fetch().map((_ref3) => Promise.asyncApply(() => {
        let {
          _id,
          label,
          details,
          username,
          password
        } = _ref3;
        const {
          hostname,
          port
        } = details;
        const uri = Promise.await(api.getStreamUri(hostname, port, username, password));
        this.start({
          id: _id,
          name: label,
          uri
        });
      }));
      Promise.all(promises);
    };
  }

}

const recorder = new Recorder();
module.exportDefault({
  start: recorder.start,
  stop: recorder.stop,
  startup: recorder.startup
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/routes.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Picker;
module.link("meteor/meteorhacks:picker", {
  Picker(v) {
    Picker = v;
  }

}, 0);
let Camera;
module.link("./camera", {
  default(v) {
    Camera = v;
  }

}, 1);
module.exportDefault(() => {
  Picker.route('/camera/:id', (params, request, response) => {
    (() => Promise.asyncApply(() => {
      try {
        const {
          id
        } = params;
        const stream = Promise.await(Camera.handleStream(id));
        stream.on('start', function () {
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          console.info('FFMPEG Stream has started: ', ...args);
          response.writeHead(200, {
            'Content-Type': 'video/mp4'
          });
        }); // stream.on("progress", (...args) => console.info("FFMPEG Stream in progress: ", ...args));
        // stream.on("stderr", (...args) => console.error('FFMPEG.stream.on("stderr": ', ...args));
        // stream.on("error", (...args) => console.error('FFMPEG.stream.on("error" : ', ...args));

        stream.on('error', () => {});
        stream.on('end', function () {
          for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
            args[_key2] = arguments[_key2];
          }

          return console.info('FFMPEG Stream is ended up: ', ...args);
        });
        stream.pipe(response);
        response.on('pipe', () => console.info('Start piping to response stream.'));
        response.on('unpipe', () => console.info('Stop piping to response stream.'));
        response.on('close', () => {
          console.info('Response stream closed.');
          stream.kill();
        });
        response.on('end', () => console.info('Response stream ended.'));
      } catch (err) {
        console.error(err);
        response.end('An error occured');
      }
    }))();
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ssr.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/ssr.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 1);
let ReactDOMServer;
module.link("react-dom/server", {
  default(v) {
    ReactDOMServer = v;
  }

}, 2);
let ServerStyleSheets, ThemeProvider;
module.link("@material-ui/core/styles", {
  ServerStyleSheets(v) {
    ServerStyleSheets = v;
  },

  ThemeProvider(v) {
    ThemeProvider = v;
  }

}, 3);
let theme;
module.link("../ui/theme", {
  default(v) {
    theme = v;
  }

}, 4);
let Preloader;
module.link("../ui/components/Preloader", {
  default(v) {
    Preloader = v;
  }

}, 5);

const getBodyContent = styleSheets => ReactDOMServer.renderToString(styleSheets.collect( /*#__PURE__*/React.createElement(ThemeProvider, {
  theme: theme
}, /*#__PURE__*/React.createElement(Preloader, null))));

module.exportDefault(elementId => {
  onPageLoad(sink => {
    const styleSheets = new ServerStyleSheets();
    sink.renderIntoElementById(elementId, getBodyContent(styleSheets));
    sink.appendToHead("<style id=\"#jss-server-side\">".concat(styleSheets.toString(), "</style>"));
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/config.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  APP: () => APP,
  RECORDER: () => RECORDER
});
let ENV;
module.link("./env", {
  default(v) {
    ENV = v;
  }

}, 0);
const APP = {
  TITLE: ENV.APP.TITLE || 'Dumb Home'
};
const RECORDER = {
  FOLDER: ENV.RECORDER.FOLDER,
  SEGMENT_TIME: ENV.RECORDER.SEGMENT_TIME,
  DIR_SIZE_THRESHOLD: ENV.RECORDER.DIR_SIZE_THRESHOLD,
  AUTO_CLEAR: ENV.AUTO_CLEAR === undefined ? true : ENV.RECORDER.AUTO_CLEAR
};
module.exportDefault({
  APP,
  RECORDER
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"devices.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/devices.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exportDefault({
  CAMERA: 'CAMERA'
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"env.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/env.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  APP: () => APP,
  SUPERUSER: () => SUPERUSER,
  RECORDER: () => RECORDER
});
const {
  SUPERUSER_NAME,
  SUPERUSER_EMAIL,
  SUPERUSER_PASSWORD,
  APP_TITLE,
  RECORDER_FOLDER,
  RECORDER_SEGMENT_TIME,
  RECORDER_DIR_SIZE_THRESHOLD,
  RECORDER_AUTO_CLEAR
} = process.env;
const APP = {
  TITLE: APP_TITLE
};
const SUPERUSER = {
  NAME: SUPERUSER_NAME,
  EMAIL: SUPERUSER_EMAIL,
  PASSWORD: SUPERUSER_PASSWORD
};
const RECORDER = {
  FOLDER: RECORDER_FOLDER,
  SEGMENT_TIME: RECORDER_SEGMENT_TIME,
  DIR_SIZE_THRESHOLD: RECORDER_DIR_SIZE_THRESHOLD,
  AUTO_CLEAR: RECORDER_AUTO_CLEAR
};
module.exportDefault({
  SUPERUSER,
  APP,
  RECORDER
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/methods.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exportDefault({
  DISCOVER_CAMERA: 'DISCOVER_CAMERA',
  CAMERA_GET_STREAM_URI: 'CAMERA_GET_STREAM_URI',
  CAMERA_RECORD_START: 'CAMERA_RECORD_START',
  CAMERA_RECORD_STOP: 'CAMERA_RECORD_STOP'
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/utils.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  ObservableCollection: () => ObservableCollection
});
let Tracker;
module.link("meteor/tracker", {
  Tracker(v) {
    Tracker = v;
  }

}, 0);
let Observable;
module.link("rxjs", {
  Observable(v) {
    Observable = v;
  }

}, 1);

const ObservableCollection = query => {
  const computations = {};

  const subscribe = (_ref) => {
    let {
      payload
    } = _ref;
    return new Observable(observer => {
      Tracker.autorun(computation => Promise.asyncApply(() => {
        computations[payload] = computation;
        observer.next(Promise.await(query(payload)));
      }), {
        onError: observer.error
      });
    });
  };

  const unsubscribe = (_ref2) => {
    let {
      payload
    } = _ref2;
    return new Observable(observer => {
      if (computations[payload]) {
        computations[payload].stop();
        observer.complete();
      }
    });
  };

  return {
    subscribe,
    unsubscribe
  };
};

module.exportDefault({
  ObservableCollection
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SSR;
module.link("../imports/server/ssr", {
  default(v) {
    SSR = v;
  }

}, 1);
let Accounts;
module.link("../imports/server/accounts", {
  default(v) {
    Accounts = v;
  }

}, 2);
let Methods;
module.link("../imports/server/methods", {
  default(v) {
    Methods = v;
  }

}, 3);
let Publish;
module.link("../imports/server/publish", {
  default(v) {
    Publish = v;
  }

}, 4);
let Recorder;
module.link("../imports/server/recorder", {
  default(v) {
    Recorder = v;
  }

}, 5);
let Routes;
module.link("../imports/server/routes", {
  default(v) {
    Routes = v;
  }

}, 6);
Meteor.startup(() => {
  SSR('viewport-root');
  Accounts.createSuperUser();
  Accounts.onCreateHook();
  Meteor.methods(Methods);
  Recorder.startup();
  Publish();
  Routes();
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91aS9jb21wb25lbnRzL1ByZWxvYWRlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91aS90aGVtZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY2FtZXJhLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZXZpY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb25zL2RldmljZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmVyL2FjY291bnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZlci9jYW1lcmEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmVyL3B1Ymxpc2guanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmVyL3JlY29yZGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZlci9yb3V0ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmVyL3Nzci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb25maWcuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvZGV2aWNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9lbnYuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiUHJvcFR5cGVzIiwibW9kdWxlIiwibGluayIsImRlZmF1bHQiLCJ2IiwiUmVhY3QiLCJ3aXRoU3R5bGVzIiwieWVsbG93IiwiUHJlbG9hZGVyIiwiY2xhc3NlcyIsIm92ZXJsYXkiLCJjaXJjdWxhciIsInByb3BUeXBlcyIsIm9iamVjdE9mIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsImV4cG9ydERlZmF1bHQiLCJ0aGVtZSIsInBvc2l0aW9uIiwidG9wIiwibGVmdCIsIndpZHRoIiwiaGVpZ2h0IiwiekluZGV4IiwiYmFja2dyb3VuZENvbG9yIiwidHJhbnNpdGlvbiIsImRpc3BsYXkiLCJtYXJnaW4iLCJib3JkZXJSYWRpdXMiLCJib3JkZXIiLCJhbmltYXRpb24iLCJib3JkZXJUb3BDb2xvciIsInBhbGV0dGUiLCJwcmltYXJ5IiwibWFpbiIsImNvbnRlbnQiLCJzZWNvbmRhcnkiLCJyaWdodCIsImJvdHRvbSIsIkE0MDAiLCJ0cmFuc2Zvcm0iLCJkZWVwT3JhbmdlIiwiaW5kaWdvIiwiY3JlYXRlTXVpVGhlbWUiLCJ0eXBlIiwidHlwb2dyYXBoeSIsImZvbnRGYW1pbHkiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJoMSIsImgyIiwiaDMiLCJoNCIsImg1IiwiaDYiLCJfb2JqZWN0U3ByZWFkIiwiTWV0ZW9yIiwiRGV2aWNlcyIsIk1FVEhPRFMiLCJERVZJQ0VTIiwiZGlzY292ZXIiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImNhbGwiLCJESVNDT1ZFUl9DQU1FUkEiLCJlcnIiLCJyZXNwb25zZSIsImVycm9yIiwiYWRkIiwicGFyYW1zIiwiaG9zdG5hbWUiLCJwb3J0IiwiZGV0YWlscyIsImluc2VydCIsIkNBTUVSQSIsIm93bmVyIiwidXNlcklkIiwiZWRpdCIsIl9pZCIsImxhYmVsIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsInVwZGF0ZSIsIiRzZXQiLCJnZXRTdHJlYW1VcmkiLCJDQU1FUkFfR0VUX1NUUkVBTV9VUkkiLCJ1cmkiLCJzdGFydFJlY29yZCIsImlkIiwiZmluZE9uZSIsIkNBTUVSQV9SRUNPUkRfU1RBUlQiLCJuYW1lIiwic3RvcFJlY29yZCIsIkNBTUVSQV9SRUNPUkRfU1RPUCIsIk9ic2VydmFibGVDb2xsZWN0aW9uIiwiZmluZCIsImZldGNoIiwicmVtb3ZlIiwib2JzZXJ2YWJsZURldmljZSIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIk1ldGVvckFjY291bnRzIiwiQWNjb3VudHMiLCJSb2xlcyIsIlNVUEVSVVNFUiIsIm9uQ3JlYXRlSG9vayIsIm9uQ3JlYXRlVXNlciIsIm9wdGlvbnMiLCJ1c2VyIiwicm9sZXMiLCJyb2xlIiwicHVzaCIsImFkZFVzZXJzVG9Sb2xlcyIsIkdMT0JBTF9HUk9VUCIsImNyZWF0ZVN1cGVyVXNlciIsIk5BTUUiLCJFTUFJTCIsIlBBU1NXT1JEIiwiY29uc29sZSIsImluZm8iLCJ1c2VycyIsImNvdW50IiwiY3JlYXRlVXNlciIsImVtYWlsIiwiZmZtcGVnIiwiRGlzY292ZXJ5IiwiQ2FtIiwicHJvYmUiLCJjYW1zIiwiRXJyb3IiLCJwcm90b2NvbCIsInN0cmVhbSIsImdldFN0cmVhbSIsInNvdXJjZSIsImxvZ2dlciIsIm5vQXVkaW8iLCJ2aWRlb0NvZGVjIiwidG9Gb3JtYXQiLCJvdXRwdXRPcHRpb25zIiwiaGFuZGxlU3RyZWFtIiwic3RyZWFtVXJpIiwiQ2FtZXJhIiwiUmVjb3JkZXIiLCJzdGFydCIsInN0b3AiLCJwdWJsaXNoIiwiUnRzcFJlY29yZGVyIiwiUmVjb3JkZXJFdmVudHMiLCJSRUNPUkRFUiIsImFwaSIsIlJlZ2lzdHJ5IiwiZ2V0UmVjb3JkZXJJbnN0YW5jZSIsIkZPTERFUiIsIlNFR01FTlRfVElNRSIsIkRJUl9TSVpFX1RIUkVTSE9MRCIsIkFVVE9fQ0xFQVIiLCJyZWNvcmRlciIsInRpdGxlIiwiZmlsZW5hbWVQYXR0ZXJuIiwicmVwbGFjZSIsInNlZ21lbnRUaW1lIiwiZGlyU2l6ZVRocmVzaG9sZCIsImF1dG9DbGVhciIsIm9uIiwiU1RBUlRFRCIsImFyZ3MiLCJsb2ciLCJEYXRlIiwiU1RPUFBFRCIsIlNUT1AiLCJQUk9HUkVTUyIsImJ1ZmZlciIsInBheWxvYWQiLCJ0b1N0cmluZyIsInRlc3QiLCJFUlJPUiIsIlNFR01FTlRfU1RBUlRFRCIsIkRJUkVDVE9SWV9DUkVBVEVEIiwiRklMRV9DUkVBVEVEIiwiU1BBQ0VfRlVMTCIsIlNQQUNFX1dJUEVEIiwiYmluZEVudmlyb25tZW50IiwicmVjb3JkaW5nIiwic3RhcnR1cCIsInByb21pc2VzIiwibWFwIiwiYWxsIiwiUGlja2VyIiwicm91dGUiLCJyZXF1ZXN0Iiwid3JpdGVIZWFkIiwicGlwZSIsImtpbGwiLCJlbmQiLCJvblBhZ2VMb2FkIiwiUmVhY3RET01TZXJ2ZXIiLCJTZXJ2ZXJTdHlsZVNoZWV0cyIsIlRoZW1lUHJvdmlkZXIiLCJnZXRCb2R5Q29udGVudCIsInN0eWxlU2hlZXRzIiwicmVuZGVyVG9TdHJpbmciLCJjb2xsZWN0IiwiZWxlbWVudElkIiwic2luayIsInJlbmRlckludG9FbGVtZW50QnlJZCIsImFwcGVuZFRvSGVhZCIsImV4cG9ydCIsIkFQUCIsIkVOViIsIlRJVExFIiwidW5kZWZpbmVkIiwiU1VQRVJVU0VSX05BTUUiLCJTVVBFUlVTRVJfRU1BSUwiLCJTVVBFUlVTRVJfUEFTU1dPUkQiLCJBUFBfVElUTEUiLCJSRUNPUkRFUl9GT0xERVIiLCJSRUNPUkRFUl9TRUdNRU5UX1RJTUUiLCJSRUNPUkRFUl9ESVJfU0laRV9USFJFU0hPTEQiLCJSRUNPUkRFUl9BVVRPX0NMRUFSIiwicHJvY2VzcyIsImVudiIsIlRyYWNrZXIiLCJPYnNlcnZhYmxlIiwicXVlcnkiLCJjb21wdXRhdGlvbnMiLCJzdWJzY3JpYmUiLCJvYnNlcnZlciIsImF1dG9ydW4iLCJjb21wdXRhdGlvbiIsIm5leHQiLCJvbkVycm9yIiwidW5zdWJzY3JpYmUiLCJjb21wbGV0ZSIsIlNTUiIsIk1ldGhvZHMiLCJQdWJsaXNoIiwiUm91dGVzIiwibWV0aG9kcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxTQUFKO0FBQWNDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0osYUFBUyxHQUFDSSxDQUFWO0FBQVk7O0FBQXhCLENBQXpCLEVBQW1ELENBQW5EO0FBQXNELElBQUlDLEtBQUo7QUFBVUosTUFBTSxDQUFDQyxJQUFQLENBQVksT0FBWixFQUFvQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBcEIsQ0FBcEIsRUFBMEMsQ0FBMUM7QUFBNkMsSUFBSUUsVUFBSjtBQUFlTCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDSSxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBaEMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSUcsTUFBSjtBQUFXTixNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDSyxRQUFNLENBQUNILENBQUQsRUFBRztBQUFDRyxVQUFNLEdBQUNILENBQVA7QUFBUzs7QUFBcEIsQ0FBdkMsRUFBNkQsQ0FBN0Q7O0FBTXROLE1BQU1JLFNBQVMsR0FBRztBQUFBLE1BQUM7QUFBRUM7QUFBRixHQUFEO0FBQUEsc0JBQ2hCO0FBQUssYUFBUyxFQUFFQSxPQUFPLENBQUNDO0FBQXhCLGtCQUNFO0FBQUssYUFBUyxFQUFFRCxPQUFPLENBQUNFO0FBQXhCLFNBREYsQ0FEZ0I7QUFBQSxDQUFsQjs7QUFNQUgsU0FBUyxDQUFDSSxTQUFWLEdBQXNCO0FBQ3BCSCxTQUFPLEVBQUVULFNBQVMsQ0FBQ2EsUUFBVixDQUFtQmIsU0FBUyxDQUFDYyxNQUE3QixFQUFxQ0M7QUFEMUIsQ0FBdEI7QUFaQWQsTUFBTSxDQUFDZSxhQUFQLENBZ0JlVixVQUFVLENBQUVXLEtBQUQsS0FBWTtBQUNwQ1AsU0FBTyxFQUFFO0FBQ1BRLFlBQVEsRUFBRSxPQURIO0FBRVBDLE9BQUcsRUFBRSxDQUZFO0FBR1BDLFFBQUksRUFBRSxDQUhDO0FBSVBDLFNBQUssRUFBRSxNQUpBO0FBS1BDLFVBQU0sRUFBRSxNQUxEO0FBTVBDLFVBQU0sRUFBRSxJQU5EO0FBT1BDLG1CQUFlLEVBQUUsc0JBUFY7QUFRUEMsY0FBVSxFQUFFO0FBUkwsR0FEMkI7QUFXcENkLFVBQVEsRUFBRTtBQUNSZSxXQUFPLEVBQUUsT0FERDtBQUVSUixZQUFRLEVBQUUsVUFGRjtBQUdSRSxRQUFJLEVBQUUsS0FIRTtBQUlSRCxPQUFHLEVBQUUsS0FKRztBQUtSRSxTQUFLLEVBQUUsR0FMQztBQU1SQyxVQUFNLEVBQUUsR0FOQTtBQU9SSyxVQUFNLEVBQUUsaUJBUEE7QUFRUkMsZ0JBQVksRUFBRSxLQVJOO0FBU1JDLFVBQU0sRUFBRSx1QkFUQTtBQVVSQyxhQUFTLEVBQUUsMEJBVkg7QUFXUkMsa0JBQWMsRUFBRWQsS0FBSyxDQUFDZSxPQUFOLENBQWNDLE9BQWQsQ0FBc0JDLElBWDlCO0FBWVIsZ0JBQVk7QUFDVkMsYUFBTyxFQUFFLElBREM7QUFFVmpCLGNBQVEsRUFBRSxVQUZBO0FBR1ZVLGtCQUFZLEVBQUUsS0FISjtBQUlWQyxZQUFNLEVBQUUsdUJBSkU7QUFLVkMsZUFBUyxFQUFFLDBCQUxEO0FBTVZDLG9CQUFjLEVBQUVkLEtBQUssQ0FBQ2UsT0FBTixDQUFjSSxTQUFkLENBQXdCRixJQU45QjtBQU9WZixTQUFHLEVBQUUsQ0FQSztBQVFWQyxVQUFJLEVBQUUsQ0FSSTtBQVNWaUIsV0FBSyxFQUFFLENBVEc7QUFVVkMsWUFBTSxFQUFFO0FBVkUsS0FaSjtBQXdCUixlQUFXO0FBQ1RILGFBQU8sRUFBRSxJQURBO0FBRVRqQixjQUFRLEVBQUUsVUFGRDtBQUdUVSxrQkFBWSxFQUFFLEtBSEw7QUFJVEMsWUFBTSxFQUFFLHVCQUpDO0FBS1RDLGVBQVMsRUFBRSw0QkFMRjtBQU1UQyxvQkFBYyxFQUFFeEIsTUFBTSxDQUFDZ0MsSUFOZDtBQU9UcEIsU0FBRyxFQUFFLEVBUEk7QUFRVEMsVUFBSSxFQUFFLEVBUkc7QUFTVGlCLFdBQUssRUFBRSxFQVRFO0FBVVRDLFlBQU0sRUFBRTtBQVZDO0FBeEJILEdBWDBCO0FBZ0RwQyxxQkFBbUI7QUFDakIsVUFBTTtBQUNKRSxlQUFTLEVBQUU7QUFEUCxLQURXO0FBSWpCLFlBQVE7QUFDTkEsZUFBUyxFQUFFO0FBREw7QUFKUztBQWhEaUIsQ0FBWixDQUFELENBQVYsQ0F3RFhoQyxTQXhEVyxDQWhCZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlpQyxVQUFKLEVBQWVDLE1BQWY7QUFBc0J6QyxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDdUMsWUFBVSxDQUFDckMsQ0FBRCxFQUFHO0FBQUNxQyxjQUFVLEdBQUNyQyxDQUFYO0FBQWEsR0FBNUI7O0FBQTZCc0MsUUFBTSxDQUFDdEMsQ0FBRCxFQUFHO0FBQUNzQyxVQUFNLEdBQUN0QyxDQUFQO0FBQVM7O0FBQWhELENBQXZDLEVBQXlGLENBQXpGO0FBQTRGLElBQUl1QyxjQUFKO0FBQW1CMUMsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ3lDLGdCQUFjLENBQUN2QyxDQUFELEVBQUc7QUFBQ3VDLGtCQUFjLEdBQUN2QyxDQUFmO0FBQWlCOztBQUFwQyxDQUF2QyxFQUE2RSxDQUE3RTtBQU1ySSxNQUFNYSxLQUFLLEdBQUcwQixjQUFjLENBQUM7QUFDM0JYLFNBQU8sRUFBRTtBQUNQQyxXQUFPLEVBQUVTLE1BREY7QUFFUE4sYUFBUyxFQUFFSyxVQUZKO0FBR1BHLFFBQUksRUFBRTtBQUhDLEdBRGtCO0FBTTNCQyxZQUFVLEVBQUU7QUFDVkMsY0FBVSxFQUFFLFFBREY7QUFFVkMsWUFBUSxFQUFFLEVBRkE7QUFHVkMsY0FBVSxFQUFFLEdBSEY7QUFJVkMsTUFBRSxFQUFFO0FBQ0ZGLGNBQVEsRUFBRTtBQURSLEtBSk07QUFPVkcsTUFBRSxFQUFFO0FBQ0ZILGNBQVEsRUFBRTtBQURSLEtBUE07QUFVVkksTUFBRSxFQUFFO0FBQ0ZKLGNBQVEsRUFBRTtBQURSLEtBVk07QUFhVkssTUFBRSxFQUFFO0FBQ0ZMLGNBQVEsRUFBRTtBQURSLEtBYk07QUFnQlZNLE1BQUUsRUFBRTtBQUNGTixjQUFRLEVBQUU7QUFEUixLQWhCTTtBQW1CVk8sTUFBRSxFQUFFO0FBQ0ZQLGNBQVEsRUFBRTtBQURSO0FBbkJNO0FBTmUsQ0FBRCxDQUE1QjtBQU5BOUMsTUFBTSxDQUFDZSxhQUFQLENBcUNlQyxLQXJDZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlzQyxhQUFKOztBQUFrQnRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNtRCxpQkFBYSxHQUFDbkQsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBbkQsRUFBaUYsQ0FBakY7QUFBbEIsSUFBSW9ELE1BQUo7QUFBV3ZELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3NELFFBQU0sQ0FBQ3BELENBQUQsRUFBRztBQUFDb0QsVUFBTSxHQUFDcEQsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUQsT0FBSjtBQUFZeEQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3FELFdBQU8sR0FBQ3JELENBQVI7QUFBVTs7QUFBdEIsQ0FBckMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSXNELE9BQUo7QUFBWXpELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3NELFdBQU8sR0FBQ3RELENBQVI7QUFBVTs7QUFBdEIsQ0FBekIsRUFBaUQsQ0FBakQ7QUFBb0QsSUFBSXVELE9BQUo7QUFBWTFELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3VELFdBQU8sR0FBQ3ZELENBQVI7QUFBVTs7QUFBdEIsQ0FBekIsRUFBaUQsQ0FBakQ7O0FBT3hOLE1BQU13RCxRQUFRLEdBQUcsTUFBTSxJQUFJQyxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ3RELE1BQUk7QUFDRlAsVUFBTSxDQUFDUSxJQUFQLENBQVlOLE9BQU8sQ0FBQ08sZUFBcEIsRUFBcUMsQ0FBQ0MsR0FBRCxFQUFNQyxRQUFOLEtBQW1CO0FBQ3RELFVBQUlELEdBQUosRUFBUyxPQUFPSCxNQUFNLENBQUNHLEdBQUQsQ0FBYjtBQUNUSixhQUFPLENBQUNLLFFBQUQsQ0FBUDtBQUNELEtBSEQ7QUFJRCxHQUxELENBS0UsT0FBT0MsS0FBUCxFQUFjO0FBQ2RMLFVBQU0sQ0FBQ0ssS0FBRCxDQUFOO0FBQ0Q7QUFDRixDQVRzQixDQUF2Qjs7QUFXQSxNQUFNQyxHQUFHLEdBQVVDLE1BQVAsNkJBQWtCO0FBQzVCLFFBQU07QUFBRUMsWUFBRjtBQUFZQztBQUFaLE1BQXFCRixNQUFNLENBQUNHLE9BQWxDO0FBQ0EsU0FBT2hCLE9BQU8sQ0FBQ2lCLE1BQVIsbUJBQ0ZKLE1BREU7QUFFTEcsV0FBTyxFQUFFO0FBQUVGLGNBQUY7QUFBWUM7QUFBWixLQUZKO0FBR0w1QixRQUFJLEVBQUVlLE9BQU8sQ0FBQ2dCLE1BSFQ7QUFJTEMsU0FBSyxFQUFFcEIsTUFBTSxDQUFDcUIsTUFBUDtBQUpGLEtBQVA7QUFNRCxDQVJXLENBQVo7O0FBVUEsTUFBTUMsSUFBSSxHQUFHO0FBQUEsTUFBTztBQUFFQyxPQUFGO0FBQU9DLFNBQVA7QUFBY0MsWUFBZDtBQUF3QkM7QUFBeEIsR0FBUDtBQUFBLFNBQ1h6QixPQUFPLENBQUMwQixNQUFSLENBQWU7QUFBRUo7QUFBRixHQUFmLEVBQXdCO0FBQUVLLFFBQUksRUFBRTtBQUFFSixXQUFGO0FBQVNDLGNBQVQ7QUFBbUJDO0FBQW5CO0FBQVIsR0FBeEIsQ0FEVztBQUFBLEVBQWIsQyxDQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBLE1BQU1HLFlBQVksR0FBRyxDQUFDZCxRQUFELEVBQVdDLElBQVgsRUFBaUJTLFFBQWpCLEVBQTJCQyxRQUEzQixLQUF3QyxJQUFJckIsT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUM1RlAsUUFBTSxDQUFDUSxJQUFQLENBQVlOLE9BQU8sQ0FBQzRCLHFCQUFwQixFQUEyQztBQUFFZixZQUFGO0FBQVlDLFFBQVo7QUFBa0JTLFlBQWxCO0FBQTRCQztBQUE1QixHQUEzQyxFQUFtRixDQUFDaEIsR0FBRCxFQUFNcUIsR0FBTixLQUFjO0FBQy9GLFFBQUlyQixHQUFKLEVBQVMsT0FBT0gsTUFBTSxDQUFDRyxHQUFELENBQWI7QUFDVEosV0FBTyxDQUFDeUIsR0FBRCxDQUFQO0FBQ0QsR0FIRDtBQUlELENBTDRELENBQTdEOztBQU9BLE1BQU1DLFdBQVcsR0FBVUMsRUFBUCw2QkFBYztBQUNoQyxRQUFNO0FBQUVULFNBQUY7QUFBU1AsV0FBVDtBQUFrQlEsWUFBbEI7QUFBNEJDO0FBQTVCLE1BQXlDekIsT0FBTyxDQUFDaUMsT0FBUixDQUFnQjtBQUFFWCxPQUFHLEVBQUVVO0FBQVAsR0FBaEIsQ0FBL0M7QUFDQSxRQUFNO0FBQUVsQixZQUFGO0FBQVlDO0FBQVosTUFBcUJDLE9BQTNCO0FBQ0EsUUFBTWMsR0FBRyxpQkFBU0YsWUFBWSxDQUFDZCxRQUFELEVBQVdDLElBQVgsRUFBaUJTLFFBQWpCLEVBQTJCQyxRQUEzQixDQUFyQixDQUFULENBSGdDLENBSWhDOztBQUNBLFNBQU8sSUFBSXJCLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDdENQLFVBQU0sQ0FBQ1EsSUFBUCxDQUFZTixPQUFPLENBQUNpQyxtQkFBcEIsRUFBeUM7QUFBRUYsUUFBRjtBQUFNRyxVQUFJLEVBQUVaLEtBQVo7QUFBbUJPO0FBQW5CLEtBQXpDLEVBQW1FLENBQUNyQixHQUFELEVBQU1DLFFBQU4sS0FBbUI7QUFDcEYsVUFBSUQsR0FBSixFQUFTLE9BQU9ILE1BQU0sQ0FBQ0csR0FBRCxDQUFiO0FBQ1RKLGFBQU8sQ0FBQ0ssUUFBRCxDQUFQO0FBQ0QsS0FIRDtBQUlELEdBTE0sQ0FBUDtBQU1ELENBWG1CLENBQXBCOztBQWFBLE1BQU0wQixVQUFVLEdBQUlKLEVBQUQsSUFBUSxJQUFJNUIsT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUMxRFAsUUFBTSxDQUFDUSxJQUFQLENBQVlOLE9BQU8sQ0FBQ29DLGtCQUFwQixFQUF3QztBQUFFTDtBQUFGLEdBQXhDLEVBQWdELENBQUN2QixHQUFELEVBQU1DLFFBQU4sS0FBbUI7QUFDakUsUUFBSUQsR0FBSixFQUFTLE9BQU9ILE1BQU0sQ0FBQ0csR0FBRCxDQUFiO0FBQ1RKLFdBQU8sQ0FBQ0ssUUFBRCxDQUFQO0FBQ0QsR0FIRDtBQUlELENBTDBCLENBQTNCOztBQXBFQWxFLE1BQU0sQ0FBQ2UsYUFBUCxDQTJFZTtBQUFFNEMsVUFBRjtBQUFZUyxLQUFaO0FBQWlCUyxNQUFqQjtBQUF1Qk8sY0FBdkI7QUFBcUNHLGFBQXJDO0FBQWtESztBQUFsRCxDQTNFZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlwQyxPQUFKO0FBQVl4RCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDcUQsV0FBTyxHQUFDckQsQ0FBUjtBQUFVOztBQUF0QixDQUFyQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJMkYsb0JBQUo7QUFBeUI5RixNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUM2RixzQkFBb0IsQ0FBQzNGLENBQUQsRUFBRztBQUFDMkYsd0JBQW9CLEdBQUMzRixDQUFyQjtBQUF1Qjs7QUFBaEQsQ0FBdkIsRUFBeUUsQ0FBekU7O0FBR3JHLE1BQU00RixJQUFJLEdBQUc7QUFBQSxTQUFhdkMsT0FBTyxDQUFDdUMsSUFBUixDQUFhLFlBQWIsQ0FBYjtBQUFBLENBQWI7O0FBRUEsTUFBTUMsS0FBSyxHQUFHO0FBQUEsU0FBYUQsSUFBSSxDQUFDLFlBQUQsQ0FBSixDQUFjQyxLQUFkLEVBQWI7QUFBQSxDQUFkOztBQUVBLE1BQU1QLE9BQU8sR0FBRztBQUFBO0FBQUEsV0FBbUJqQyxPQUFPLENBQUNpQyxPQUFSLENBQWdCLFlBQWhCLENBQW5CO0FBQUE7QUFBQSxDQUFoQjs7QUFFQSxNQUFNaEIsTUFBTSxHQUFHO0FBQUE7QUFBQSxXQUFtQmpCLE9BQU8sQ0FBQ2lCLE1BQVIsQ0FBZSxZQUFmLENBQW5CO0FBQUE7QUFBQSxDQUFmOztBQUVBLE1BQU13QixNQUFNLEdBQUc7QUFBQTtBQUFBLFdBQW1CekMsT0FBTyxDQUFDeUMsTUFBUixDQUFlLFlBQWYsQ0FBbkI7QUFBQTtBQUFBLENBQWY7O0FBRUEsTUFBTUMsZ0JBQWdCLEdBQUdKLG9CQUFvQixDQUFDTCxPQUFELENBQTdDO0FBYkF6RixNQUFNLENBQUNlLGFBQVAsQ0FlZTtBQUNiZ0YsTUFEYTtBQUViQyxPQUZhO0FBR2JQLFNBSGE7QUFJYmhCLFFBSmE7QUFLYndCLFFBTGE7QUFNYkM7QUFOYSxDQWZmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSUMsS0FBSjtBQUFVbkcsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDa0csT0FBSyxDQUFDaEcsQ0FBRCxFQUFHO0FBQUNnRyxTQUFLLEdBQUNoRyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQVZILE1BQU0sQ0FBQ2UsYUFBUCxDQUVlLElBQUlvRixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsU0FBckIsQ0FGZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUk3QyxNQUFKO0FBQVd2RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNzRCxRQUFNLENBQUNwRCxDQUFELEVBQUc7QUFBQ29ELFVBQU0sR0FBQ3BELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWtHLGNBQUo7QUFBbUJyRyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDcUcsVUFBUSxDQUFDbkcsQ0FBRCxFQUFHO0FBQUNrRyxrQkFBYyxHQUFDbEcsQ0FBZjtBQUFpQjs7QUFBOUIsQ0FBbkMsRUFBbUUsQ0FBbkU7QUFBc0UsSUFBSW9HLEtBQUo7QUFBVXZHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNzRyxPQUFLLENBQUNwRyxDQUFELEVBQUc7QUFBQ29HLFNBQUssR0FBQ3BHLENBQU47QUFBUTs7QUFBbEIsQ0FBcEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSXFHLFNBQUo7QUFBY3hHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ3VHLFdBQVMsQ0FBQ3JHLENBQUQsRUFBRztBQUFDcUcsYUFBUyxHQUFDckcsQ0FBVjtBQUFZOztBQUExQixDQUFyQixFQUFpRCxDQUFqRDtBQUE1T0gsTUFBTSxDQUFDZSxhQUFQLENBS2U7QUFDYjBGLGNBQVksR0FBRztBQUNiSixrQkFBYyxDQUFDSyxZQUFmLENBQTRCLENBQUNDLE9BQUQsRUFBVUMsSUFBVixLQUFtQjtBQUM3QyxZQUFNQyxLQUFLLEdBQUcsQ0FBQyxNQUFELENBQWQ7QUFDQSxVQUFJRixPQUFPLENBQUNHLElBQVIsS0FBaUIsT0FBckIsRUFBOEJELEtBQUssQ0FBQ0UsSUFBTixDQUFXLE9BQVg7QUFDOUJSLFdBQUssQ0FBQ1MsZUFBTixDQUFzQkosSUFBSSxDQUFDOUIsR0FBM0IsRUFBZ0MrQixLQUFoQyxFQUF1Q04sS0FBSyxDQUFDVSxZQUE3QztBQUNELEtBSkQ7QUFLRCxHQVBZOztBQVNiQyxpQkFBZSxHQUFHO0FBQ2hCLFFBQUksQ0FBQ1YsU0FBUyxDQUFDVyxJQUFYLElBQW1CLENBQUNYLFNBQVMsQ0FBQ1ksS0FBOUIsSUFBdUMsQ0FBQ1osU0FBUyxDQUFDYSxRQUF0RCxFQUFnRTtBQUM5REMsYUFBTyxDQUFDQyxJQUFSLENBQWEsMkNBQWI7QUFDQTtBQUNEOztBQUVELFFBQUloRSxNQUFNLENBQUNpRSxLQUFQLENBQWF6QixJQUFiLEdBQW9CMEIsS0FBcEIsRUFBSixFQUFpQztBQUMvQkgsYUFBTyxDQUFDQyxJQUFSLENBQWEsd0NBQWI7QUFDQTtBQUNEOztBQUVELFVBQU0zQyxNQUFNLEdBQUd5QixjQUFjLENBQUNxQixVQUFmLENBQTBCO0FBQ3ZDMUMsY0FBUSxFQUFFd0IsU0FBUyxDQUFDVyxJQURtQjtBQUV2Q1EsV0FBSyxFQUFFbkIsU0FBUyxDQUFDWSxLQUZzQjtBQUd2Q25DLGNBQVEsRUFBRXVCLFNBQVMsQ0FBQ2E7QUFIbUIsS0FBMUIsQ0FBZjtBQUtBZCxTQUFLLENBQUNTLGVBQU4sQ0FBc0JwQyxNQUF0QixFQUE4QixDQUFDLE1BQUQsRUFBUyxXQUFULENBQTlCLEVBQXFEMkIsS0FBSyxDQUFDVSxZQUEzRDtBQUVBSyxXQUFPLENBQUNDLElBQVIsQ0FBYSw2QkFBYixFQUE0QztBQUMxQy9CLFFBQUUsRUFBRVosTUFEc0M7QUFFMUNJLGNBQVEsRUFBRXdCLFNBQVMsQ0FBQ1csSUFGc0I7QUFHMUNRLFdBQUssRUFBRW5CLFNBQVMsQ0FBQ1k7QUFIeUIsS0FBNUM7QUFLRDs7QUFoQ1ksQ0FMZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlRLE1BQUo7QUFBVzVILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3lILFVBQU0sR0FBQ3pILENBQVA7QUFBUzs7QUFBckIsQ0FBNUIsRUFBbUQsQ0FBbkQ7QUFBc0QsSUFBSTBILFNBQUosRUFBY0MsR0FBZDtBQUFrQjlILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE9BQVosRUFBb0I7QUFBQzRILFdBQVMsQ0FBQzFILENBQUQsRUFBRztBQUFDMEgsYUFBUyxHQUFDMUgsQ0FBVjtBQUFZLEdBQTFCOztBQUEyQjJILEtBQUcsQ0FBQzNILENBQUQsRUFBRztBQUFDMkgsT0FBRyxHQUFDM0gsQ0FBSjtBQUFNOztBQUF4QyxDQUFwQixFQUE4RCxDQUE5RDtBQUFpRSxJQUFJcUQsT0FBSjtBQUFZeEQsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3FELFdBQU8sR0FBQ3JELENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7O0FBS2hLLE1BQU13RCxRQUFRLEdBQUcsTUFBTSxJQUFJQyxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ3RELE1BQUk7QUFDRitELGFBQVMsQ0FBQ0UsS0FBVixDQUFnQixDQUFDOUQsR0FBRCxFQUFNK0QsSUFBTixLQUFlO0FBQzdCLFVBQUkvRCxHQUFKLEVBQVMsTUFBTSxJQUFJZ0UsS0FBSixDQUFVaEUsR0FBVixDQUFOO0FBQ1RKLGFBQU8sQ0FBQ21FLElBQUQsQ0FBUDtBQUNELEtBSEQ7QUFJRCxHQUxELENBS0UsT0FBTzdELEtBQVAsRUFBYztBQUNkTCxVQUFNLENBQUNLLEtBQUQsQ0FBTjtBQUNEO0FBQ0YsQ0FUc0IsQ0FBdkI7O0FBV0EsTUFBTWlCLFlBQVksR0FBRztBQUFBLE1BQUM7QUFBRWQsWUFBRjtBQUFZQyxRQUFaO0FBQWtCUyxZQUFsQjtBQUE0QkMsWUFBUSxHQUFHO0FBQXZDLEdBQUQ7QUFBQSxTQUFpRCxJQUFJckIsT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNyRyxRQUFJO0FBQ0Y7QUFDQSxVQUFJZ0UsR0FBSixDQUNFO0FBQ0V4RCxnQkFERjtBQUVFQyxZQUZGO0FBR0VTLGdCQUhGO0FBSUVDO0FBSkYsT0FERixFQU9FLFVBQVVoQixHQUFWLEVBQWU7QUFDYixZQUFJQSxHQUFKLEVBQVMsTUFBTSxJQUFJZ0UsS0FBSixDQUFVaEUsR0FBVixDQUFOLENBREksQ0FFYjs7QUFDQSxhQUFLbUIsWUFBTCxDQUFrQjtBQUFFOEMsa0JBQVEsRUFBRTtBQUFaLFNBQWxCLEVBQXdDLENBQUNqRSxHQUFELEVBQU1rRSxNQUFOLEtBQWlCO0FBQ3ZELGNBQUlsRSxHQUFKLEVBQVMsTUFBTSxJQUFJZ0UsS0FBSixDQUFVaEUsR0FBVixDQUFOO0FBQ1RKLGlCQUFPLENBQUNzRSxNQUFNLENBQUM3QyxHQUFSLENBQVA7QUFDRCxTQUhEO0FBSUQsT0FkSDtBQWdCRCxLQWxCRCxDQWtCRSxPQUFPbkIsS0FBUCxFQUFjO0FBQ2RMLFlBQU0sQ0FBQ0ssS0FBRCxDQUFOO0FBQ0Q7QUFDRixHQXRCcUUsQ0FBakQ7QUFBQSxDQUFyQjs7QUF3QkEsTUFBTWlFLFNBQVMsR0FBSUMsTUFBRCxJQUFZVCxNQUFNLENBQUNTLE1BQUQsRUFBUztBQUFFQyxRQUFNLEVBQUVoQjtBQUFWLENBQVQsQ0FBTixDQUMzQmlCLE9BRDJCLEdBRTNCQyxVQUYyQixDQUVoQixNQUZnQixFQUczQkMsUUFIMkIsQ0FHbEIsS0FIa0IsRUFJM0JDLGFBSjJCLENBSWIsQ0FDYixpQkFEYSxFQUViLEtBRmEsRUFJYixXQUphLEVBS2IsMEJBTGEsRUFPYixtQkFQYSxFQVFiLEdBUmEsRUFVYixRQVZhLEVBV2IsR0FYYSxFQWFiLFFBYmEsRUFjYixlQWRhLEVBZ0JiLFFBaEJhLEVBaUJiLFlBakJhLENBSmEsQ0FBOUI7O0FBd0JBLE1BQU1DLFlBQVksR0FBVTdELEdBQVAsNkJBQWU7QUFDbEMsUUFBTTtBQUFFTixXQUFGO0FBQVdRLFlBQVg7QUFBcUJDO0FBQXJCLG9CQUF3Q3pCLE9BQU8sQ0FBQ2lDLE9BQVIsQ0FBZ0I7QUFBRVg7QUFBRixHQUFoQixDQUF4QyxDQUFOO0FBQ0EsUUFBTTtBQUFFUixZQUFGO0FBQVlDO0FBQVosTUFBcUJDLE9BQTNCO0FBQ0EsUUFBTW9FLFNBQVMsaUJBQVN4RCxZQUFZLENBQUM7QUFDbkNkLFlBRG1DO0FBRW5DQyxRQUZtQztBQUduQ1MsWUFIbUM7QUFJbkNDO0FBSm1DLEdBQUQsQ0FBckIsQ0FBZjtBQU1BLFNBQU9tRCxTQUFTLENBQUNRLFNBQUQsQ0FBaEI7QUFDRCxDQVZvQixDQUFyQjs7QUFoRUE1SSxNQUFNLENBQUNlLGFBQVAsQ0E0RWU7QUFBRTRDLFVBQUY7QUFBWXlCLGNBQVo7QUFBMEJ1RDtBQUExQixDQTVFZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlsRixPQUFKO0FBQVl6RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNzRCxXQUFPLEdBQUN0RCxDQUFSO0FBQVU7O0FBQXRCLENBQXpCLEVBQWlELENBQWpEO0FBQW9ELElBQUkwSSxNQUFKO0FBQVc3SSxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMwSSxVQUFNLEdBQUMxSSxDQUFQO0FBQVM7O0FBQXJCLENBQXZCLEVBQThDLENBQTlDO0FBQWlELElBQUkySSxRQUFKO0FBQWE5SSxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMySSxZQUFRLEdBQUMzSSxDQUFUO0FBQVc7O0FBQXZCLENBQXpCLEVBQWtELENBQWxEO0FBQXpJSCxNQUFNLENBQUNlLGFBQVAsQ0FJZTtBQUNiLEdBQUMwQyxPQUFPLENBQUNPLGVBQVQsR0FBMkI2RSxNQUFNLENBQUNsRixRQURyQjtBQUViLEdBQUNGLE9BQU8sQ0FBQzRCLHFCQUFULEdBQWlDd0QsTUFBTSxDQUFDekQsWUFGM0I7QUFHYixHQUFDM0IsT0FBTyxDQUFDaUMsbUJBQVQsR0FBK0JvRCxRQUFRLENBQUNDLEtBSDNCO0FBSWIsR0FBQ3RGLE9BQU8sQ0FBQ29DLGtCQUFULEdBQThCaUQsUUFBUSxDQUFDRTtBQUoxQixDQUpmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSXpGLE1BQUo7QUFBV3ZELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3NELFFBQU0sQ0FBQ3BELENBQUQsRUFBRztBQUFDb0QsVUFBTSxHQUFDcEQsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUQsT0FBSjtBQUFZeEQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3FELFdBQU8sR0FBQ3JELENBQVI7QUFBVTs7QUFBdEIsQ0FBckMsRUFBNkQsQ0FBN0Q7QUFBNUVILE1BQU0sQ0FBQ2UsYUFBUCxDQWtCZSxNQUFNO0FBQ25Cd0MsUUFBTSxDQUFDMEYsT0FBUCxDQUFlLFNBQWYsRUFBMEI7QUFBQSxXQUFhekYsT0FBTyxDQUFDdUMsSUFBUixDQUFhLFlBQWIsQ0FBYjtBQUFBLEdBQTFCO0FBQ0QsQ0FwQkQsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJbUQsWUFBSixFQUFpQkMsY0FBakI7QUFBZ0NuSixNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDK0ksZ0JBQVksR0FBQy9JLENBQWI7QUFBZSxHQUEzQjs7QUFBNEJnSixnQkFBYyxDQUFDaEosQ0FBRCxFQUFHO0FBQUNnSixrQkFBYyxHQUFDaEosQ0FBZjtBQUFpQjs7QUFBL0QsQ0FBbEMsRUFBbUcsQ0FBbkc7QUFBc0csSUFBSWlKLFFBQUo7QUFBYXBKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ21KLFVBQVEsQ0FBQ2pKLENBQUQsRUFBRztBQUFDaUosWUFBUSxHQUFDakosQ0FBVDtBQUFXOztBQUF4QixDQUF4QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJdUQsT0FBSjtBQUFZMUQsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDdUQsV0FBTyxHQUFDdkQsQ0FBUjtBQUFVOztBQUF0QixDQUF6QixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJcUQsT0FBSjtBQUFZeEQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3FELFdBQU8sR0FBQ3JELENBQVI7QUFBVTs7QUFBdEIsQ0FBckMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSWtKLEdBQUo7QUFBUXJKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2tKLE9BQUcsR0FBQ2xKLENBQUo7QUFBTTs7QUFBbEIsQ0FBNUIsRUFBZ0QsQ0FBaEQ7O0FBTTVWLE1BQU0ySSxRQUFOLENBQWU7QUFBQTtBQUFBLFNBQ2JRLFFBRGEsR0FDRixFQURFOztBQUFBLFNBR2JDLG1CQUhhLEdBR1MsQ0FBQy9ELEVBQUQsRUFBS0YsR0FBTCxFQUFVSyxJQUFWLEtBQW1CO0FBQ3ZDLFlBQU07QUFBRTZELGNBQUY7QUFBVUMsb0JBQVY7QUFBd0JDLDBCQUF4QjtBQUE0Q0M7QUFBNUMsVUFBMkRQLFFBQWpFO0FBRUEsWUFBTVEsUUFBUSxHQUFHLElBQUlWLFlBQUosQ0FBaUI1RCxHQUFqQixFQUFzQmtFLE1BQXRCLEVBQThCO0FBQzdDSyxhQUFLLEVBQUVsRSxJQURzQztBQUU3Q21FLHVCQUFlLHFCQUFjbkUsSUFBSSxDQUFDb0UsT0FBTCxDQUFhLElBQWIsRUFBbUIsSUFBbkIsQ0FBZCxDQUY4QjtBQUc3Q0MsbUJBQVcsRUFBRVAsWUFIZ0M7QUFJN0NRLHdCQUFnQixFQUFFUCxrQkFKMkI7QUFLN0NRLGlCQUFTLEVBQUVQO0FBTGtDLE9BQTlCLENBQWpCO0FBUUFDLGNBQVEsQ0FBQ08sRUFBVCxDQUFZaEIsY0FBYyxDQUFDaUIsT0FBM0IsRUFBb0MsWUFBYTtBQUFBLDBDQUFUQyxJQUFTO0FBQVRBLGNBQVM7QUFBQTs7QUFDL0MvQyxlQUFPLENBQUNnRCxHQUFSLFlBQWdCLElBQUlDLElBQUosRUFBaEIsZUFBK0JwQixjQUFjLENBQUNpQixPQUE5QyxpQkFBMkR6RSxJQUEzRCxXQUFzRSxHQUFHMEUsSUFBekU7QUFDRCxPQUZEO0FBSUFULGNBQVEsQ0FBQ08sRUFBVCxDQUFZaEIsY0FBYyxDQUFDcUIsT0FBM0IsRUFBb0MsWUFBYTtBQUFBLDJDQUFUSCxJQUFTO0FBQVRBLGNBQVM7QUFBQTs7QUFDL0MvQyxlQUFPLENBQUNnRCxHQUFSLFlBQWdCLElBQUlDLElBQUosRUFBaEIsZUFBK0JwQixjQUFjLENBQUNxQixPQUE5QyxpQkFBMkQ3RSxJQUEzRCxXQUFzRSxHQUFHMEUsSUFBekU7QUFDRCxPQUZEO0FBSUFULGNBQVEsQ0FBQ08sRUFBVCxDQUFZaEIsY0FBYyxDQUFDc0IsSUFBM0IsRUFBaUMsWUFBYTtBQUFBLDJDQUFUSixJQUFTO0FBQVRBLGNBQVM7QUFBQTs7QUFDNUMvQyxlQUFPLENBQUNnRCxHQUFSLFlBQWdCLElBQUlDLElBQUosRUFBaEIsZUFBK0JwQixjQUFjLENBQUNzQixJQUE5QyxpQkFBd0Q5RSxJQUF4RCxXQUFtRSxHQUFHMEUsSUFBdEU7QUFDRCxPQUZEO0FBSUFULGNBQVEsQ0FBQ08sRUFBVCxDQUFZaEIsY0FBYyxDQUFDdUIsUUFBM0IsRUFBc0NDLE1BQUQsSUFBWTtBQUMvQyxjQUFNQyxPQUFPLEdBQUdELE1BQU0sQ0FBQ0UsUUFBUCxFQUFoQixDQUQrQyxDQUUvQztBQUNBO0FBQ0E7O0FBQ0EsWUFDRSwrQ0FBK0NDLElBQS9DLENBQW9ERixPQUFwRCxLQUNHLHlDQUF5Q0UsSUFBekMsQ0FBOENGLE9BQTlDLENBREgsSUFFRyxhQUFhRSxJQUFiLENBQWtCRixPQUFsQixDQUhMLEVBSUU7QUFDQTtBQUNEOztBQUNEdEQsZUFBTyxDQUFDZ0QsR0FBUixZQUFnQixJQUFJQyxJQUFKLEVBQWhCLGVBQStCcEIsY0FBYyxDQUFDdUIsUUFBOUMsaUJBQTREL0UsSUFBNUQsV0FBdUVpRixPQUF2RTtBQUNELE9BYkQ7QUFlQWhCLGNBQVEsQ0FBQ08sRUFBVCxDQUFZaEIsY0FBYyxDQUFDNEIsS0FBM0IsRUFBa0MsWUFBYTtBQUFBLDJDQUFUVixJQUFTO0FBQVRBLGNBQVM7QUFBQTs7QUFDN0MvQyxlQUFPLENBQUNnRCxHQUFSLFlBQWdCLElBQUlDLElBQUosRUFBaEIsZUFBK0JwQixjQUFjLENBQUM0QixLQUE5QyxpQkFBeURwRixJQUF6RCxXQUFvRSxHQUFHMEUsSUFBdkU7QUFDRCxPQUZEO0FBSUFULGNBQVEsQ0FBQ08sRUFBVCxDQUFZaEIsY0FBYyxDQUFDNkIsZUFBM0IsRUFBNEMsWUFBYTtBQUFBLDJDQUFUWCxJQUFTO0FBQVRBLGNBQVM7QUFBQTs7QUFDdkQvQyxlQUFPLENBQUNnRCxHQUFSLFlBQWdCLElBQUlDLElBQUosRUFBaEIsZUFBK0JwQixjQUFjLENBQUM2QixlQUE5QyxpQkFBbUVyRixJQUFuRSxXQUE4RSxHQUFHMEUsSUFBakY7QUFDRCxPQUZEO0FBSUFULGNBQVEsQ0FBQ08sRUFBVCxDQUFZaEIsY0FBYyxDQUFDOEIsaUJBQTNCLEVBQThDLFlBQWE7QUFBQSwyQ0FBVFosSUFBUztBQUFUQSxjQUFTO0FBQUE7O0FBQ3pEL0MsZUFBTyxDQUFDZ0QsR0FBUixZQUFnQixJQUFJQyxJQUFKLEVBQWhCLGVBQStCcEIsY0FBYyxDQUFDOEIsaUJBQTlDLGlCQUFxRXRGLElBQXJFLFdBQWdGLEdBQUcwRSxJQUFuRjtBQUNELE9BRkQ7QUFJQVQsY0FBUSxDQUFDTyxFQUFULENBQVloQixjQUFjLENBQUMrQixZQUEzQixFQUF5QyxZQUFhO0FBQUEsMkNBQVRiLElBQVM7QUFBVEEsY0FBUztBQUFBOztBQUNwRC9DLGVBQU8sQ0FBQ2dELEdBQVIsWUFBZ0IsSUFBSUMsSUFBSixFQUFoQixlQUErQnBCLGNBQWMsQ0FBQytCLFlBQTlDLGlCQUFnRXZGLElBQWhFLFdBQTJFLEdBQUcwRSxJQUE5RTtBQUNELE9BRkQ7QUFJQVQsY0FBUSxDQUFDTyxFQUFULENBQVloQixjQUFjLENBQUNnQyxVQUEzQixFQUF1QyxZQUFhO0FBQUEsMkNBQVRkLElBQVM7QUFBVEEsY0FBUztBQUFBOztBQUNsRC9DLGVBQU8sQ0FBQ2dELEdBQVIsWUFBZ0IsSUFBSUMsSUFBSixFQUFoQixlQUErQnBCLGNBQWMsQ0FBQ2dDLFVBQTlDLGlCQUE4RHhGLElBQTlELFdBQXlFLEdBQUcwRSxJQUE1RTtBQUNELE9BRkQ7QUFJQVQsY0FBUSxDQUFDTyxFQUFULENBQVloQixjQUFjLENBQUNpQyxXQUEzQixFQUF3QyxZQUFhO0FBQUEsMkNBQVRmLElBQVM7QUFBVEEsY0FBUztBQUFBOztBQUNuRC9DLGVBQU8sQ0FBQ2dELEdBQVIsWUFBZ0IsSUFBSUMsSUFBSixFQUFoQixlQUErQnBCLGNBQWMsQ0FBQ2lDLFdBQTlDLGlCQUErRHpGLElBQS9ELFdBQTBFLEdBQUcwRSxJQUE3RTtBQUNELE9BRkQ7QUFJQSxhQUFPVCxRQUFQO0FBQ0QsS0FsRVk7O0FBQUEsU0FvRWJiLEtBcEVhLEdBb0VMLFVBQXVCO0FBQUEsVUFBdEI7QUFBRXZELFVBQUY7QUFBTUcsWUFBTjtBQUFZTDtBQUFaLE9BQXNCO0FBQzdCLFlBQU1zRSxRQUFRLEdBQUcsS0FBS0wsbUJBQUwsQ0FBeUIvRCxFQUF6QixFQUE2QkYsR0FBN0IsRUFBa0NLLElBQWxDLENBQWpCO0FBQ0FpRSxjQUFRLENBQ0xPLEVBREgsQ0FDTSxTQUROLEVBQ2lCNUcsTUFBTSxDQUFDOEgsZUFBUCxDQUF1QixNQUFNO0FBQzFDN0gsZUFBTyxDQUFDMEIsTUFBUixDQUFlO0FBQUVKLGFBQUcsRUFBRVU7QUFBUCxTQUFmLEVBQTRCO0FBQUVMLGNBQUksRUFBRTtBQUFFbUcscUJBQVMsRUFBRTtBQUFiO0FBQVIsU0FBNUI7QUFDRCxPQUZjLENBRGpCLEVBSUd2QyxLQUpIO0FBS0F2RixhQUFPLENBQUMwQixNQUFSLENBQWU7QUFBRUosV0FBRyxFQUFFVTtBQUFQLE9BQWYsRUFBNEI7QUFBRUwsWUFBSSxFQUFFO0FBQUVtRyxtQkFBUyxFQUFFO0FBQWI7QUFBUixPQUE1QjtBQUNBLFdBQUtoQyxRQUFMLENBQWM5RCxFQUFkLElBQW9Cb0UsUUFBcEI7QUFDRCxLQTdFWTs7QUFBQSxTQStFYlosSUEvRWEsR0ErRU4sV0FBWTtBQUFBLFVBQVg7QUFBRXhEO0FBQUYsT0FBVztBQUNqQixZQUFNb0UsUUFBUSxHQUFHLEtBQUtOLFFBQUwsQ0FBYzlELEVBQWQsQ0FBakI7O0FBQ0EsVUFBSW9FLFFBQUosRUFBYztBQUNaQSxnQkFBUSxDQUFDWixJQUFUO0FBQ0Q7O0FBQ0R4RixhQUFPLENBQUMwQixNQUFSLENBQWU7QUFBRUosV0FBRyxFQUFFVTtBQUFQLE9BQWYsRUFBNEI7QUFBRUwsWUFBSSxFQUFFO0FBQUVtRyxtQkFBUyxFQUFFO0FBQWI7QUFBUixPQUE1QjtBQUNELEtBckZZOztBQUFBLFNBdUZiQyxPQXZGYSxHQXVGSCxNQUFNO0FBQ2QsWUFBTUMsUUFBUSxHQUFHaEksT0FBTyxDQUFDdUMsSUFBUixDQUFhO0FBQUVwRCxZQUFJLEVBQUVlLE9BQU8sQ0FBQ2dCLE1BQWhCO0FBQXdCNEcsaUJBQVMsRUFBRTtBQUFuQyxPQUFiLEVBQ2R0RixLQURjLEdBRWR5RixHQUZjLENBRVYsb0NBQXVEO0FBQUEsWUFBaEQ7QUFBRTNHLGFBQUY7QUFBT0MsZUFBUDtBQUFjUCxpQkFBZDtBQUF1QlEsa0JBQXZCO0FBQWlDQztBQUFqQyxTQUFnRDtBQUMxRCxjQUFNO0FBQUVYLGtCQUFGO0FBQVlDO0FBQVosWUFBcUJDLE9BQTNCO0FBQ0EsY0FBTWMsR0FBRyxpQkFBUytELEdBQUcsQ0FBQ2pFLFlBQUosQ0FBaUJkLFFBQWpCLEVBQTJCQyxJQUEzQixFQUFpQ1MsUUFBakMsRUFBMkNDLFFBQTNDLENBQVQsQ0FBVDtBQUNBLGFBQUs4RCxLQUFMLENBQVc7QUFBRXZELFlBQUUsRUFBRVYsR0FBTjtBQUFXYSxjQUFJLEVBQUVaLEtBQWpCO0FBQXdCTztBQUF4QixTQUFYO0FBQ0QsT0FKSSxDQUZVLENBQWpCO0FBT0ExQixhQUFPLENBQUM4SCxHQUFSLENBQVlGLFFBQVo7QUFDRCxLQWhHWTtBQUFBOztBQUFBOztBQW1HZixNQUFNNUIsUUFBUSxHQUFHLElBQUlkLFFBQUosRUFBakI7QUF6R0E5SSxNQUFNLENBQUNlLGFBQVAsQ0EyR2U7QUFDYmdJLE9BQUssRUFBRWEsUUFBUSxDQUFDYixLQURIO0FBRWJDLE1BQUksRUFBRVksUUFBUSxDQUFDWixJQUZGO0FBR2J1QyxTQUFPLEVBQUUzQixRQUFRLENBQUMyQjtBQUhMLENBM0dmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSUksTUFBSjtBQUFXM0wsTUFBTSxDQUFDQyxJQUFQLENBQVksMkJBQVosRUFBd0M7QUFBQzBMLFFBQU0sQ0FBQ3hMLENBQUQsRUFBRztBQUFDd0wsVUFBTSxHQUFDeEwsQ0FBUDtBQUFTOztBQUFwQixDQUF4QyxFQUE4RCxDQUE5RDtBQUFpRSxJQUFJMEksTUFBSjtBQUFXN0ksTUFBTSxDQUFDQyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDMEksVUFBTSxHQUFDMUksQ0FBUDtBQUFTOztBQUFyQixDQUF2QixFQUE4QyxDQUE5QztBQUF2RkgsTUFBTSxDQUFDZSxhQUFQLENBR2UsTUFBTTtBQUNuQjRLLFFBQU0sQ0FBQ0MsS0FBUCxDQUFhLGFBQWIsRUFBNEIsQ0FBQ3ZILE1BQUQsRUFBU3dILE9BQVQsRUFBa0IzSCxRQUFsQixLQUErQjtBQUN6RCxLQUFDLCtCQUFZO0FBQ1gsVUFBSTtBQUNGLGNBQU07QUFBRXNCO0FBQUYsWUFBU25CLE1BQWY7QUFDQSxjQUFNOEQsTUFBTSxpQkFBU1UsTUFBTSxDQUFDRixZQUFQLENBQW9CbkQsRUFBcEIsQ0FBVCxDQUFaO0FBRUEyQyxjQUFNLENBQUNnQyxFQUFQLENBQVUsT0FBVixFQUFtQixZQUFhO0FBQUEsNENBQVRFLElBQVM7QUFBVEEsZ0JBQVM7QUFBQTs7QUFDOUIvQyxpQkFBTyxDQUFDQyxJQUFSLENBQWEsNkJBQWIsRUFBNEMsR0FBRzhDLElBQS9DO0FBQ0FuRyxrQkFBUSxDQUFDNEgsU0FBVCxDQUFtQixHQUFuQixFQUF3QjtBQUFFLDRCQUFnQjtBQUFsQixXQUF4QjtBQUNELFNBSEQsRUFKRSxDQVFGO0FBQ0E7QUFDQTs7QUFDQTNELGNBQU0sQ0FBQ2dDLEVBQVAsQ0FBVSxPQUFWLEVBQW1CLE1BQU0sQ0FBRSxDQUEzQjtBQUNBaEMsY0FBTSxDQUFDZ0MsRUFBUCxDQUFVLEtBQVYsRUFBaUI7QUFBQSw2Q0FBSUUsSUFBSjtBQUFJQSxnQkFBSjtBQUFBOztBQUFBLGlCQUFhL0MsT0FBTyxDQUFDQyxJQUFSLENBQWEsNkJBQWIsRUFBNEMsR0FBRzhDLElBQS9DLENBQWI7QUFBQSxTQUFqQjtBQUVBbEMsY0FBTSxDQUFDNEQsSUFBUCxDQUFZN0gsUUFBWjtBQUVBQSxnQkFBUSxDQUFDaUcsRUFBVCxDQUFZLE1BQVosRUFBb0IsTUFBTTdDLE9BQU8sQ0FBQ0MsSUFBUixDQUFhLGtDQUFiLENBQTFCO0FBQ0FyRCxnQkFBUSxDQUFDaUcsRUFBVCxDQUFZLFFBQVosRUFBc0IsTUFBTTdDLE9BQU8sQ0FBQ0MsSUFBUixDQUFhLGlDQUFiLENBQTVCO0FBQ0FyRCxnQkFBUSxDQUFDaUcsRUFBVCxDQUFZLE9BQVosRUFBcUIsTUFBTTtBQUN6QjdDLGlCQUFPLENBQUNDLElBQVIsQ0FBYSx5QkFBYjtBQUNBWSxnQkFBTSxDQUFDNkQsSUFBUDtBQUNELFNBSEQ7QUFJQTlILGdCQUFRLENBQUNpRyxFQUFULENBQVksS0FBWixFQUFtQixNQUFNN0MsT0FBTyxDQUFDQyxJQUFSLENBQWEsd0JBQWIsQ0FBekI7QUFDRCxPQXZCRCxDQXVCRSxPQUFPdEQsR0FBUCxFQUFZO0FBQ1pxRCxlQUFPLENBQUNuRCxLQUFSLENBQWNGLEdBQWQ7QUFDQUMsZ0JBQVEsQ0FBQytILEdBQVQsQ0FBYSxrQkFBYjtBQUNEO0FBQ0YsS0E1QkEsQ0FBRDtBQTZCRCxHQTlCRDtBQStCRCxDQW5DRCxFOzs7Ozs7Ozs7OztBQ0FBLElBQUk3TCxLQUFKO0FBQVVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE9BQVosRUFBb0I7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQXBCLENBQXBCLEVBQTBDLENBQTFDO0FBQTZDLElBQUkrTCxVQUFKO0FBQWVsTSxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDaU0sWUFBVSxDQUFDL0wsQ0FBRCxFQUFHO0FBQUMrTCxjQUFVLEdBQUMvTCxDQUFYO0FBQWE7O0FBQTVCLENBQW5DLEVBQWlFLENBQWpFO0FBQW9FLElBQUlnTSxjQUFKO0FBQW1Cbk0sTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2dNLGtCQUFjLEdBQUNoTSxDQUFmO0FBQWlCOztBQUE3QixDQUEvQixFQUE4RCxDQUE5RDtBQUFpRSxJQUFJaU0saUJBQUosRUFBc0JDLGFBQXRCO0FBQW9Dck0sTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ21NLG1CQUFpQixDQUFDak0sQ0FBRCxFQUFHO0FBQUNpTSxxQkFBaUIsR0FBQ2pNLENBQWxCO0FBQW9CLEdBQTFDOztBQUEyQ2tNLGVBQWEsQ0FBQ2xNLENBQUQsRUFBRztBQUFDa00saUJBQWEsR0FBQ2xNLENBQWQ7QUFBZ0I7O0FBQTVFLENBQXZDLEVBQXFILENBQXJIO0FBQXdILElBQUlhLEtBQUo7QUFBVWhCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ2EsU0FBSyxHQUFDYixDQUFOO0FBQVE7O0FBQXBCLENBQTFCLEVBQWdELENBQWhEO0FBQW1ELElBQUlJLFNBQUo7QUFBY1AsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0ksYUFBUyxHQUFDSixDQUFWO0FBQVk7O0FBQXhCLENBQXpDLEVBQW1FLENBQW5FOztBQVVyYyxNQUFNbU0sY0FBYyxHQUFJQyxXQUFELElBQWlCSixjQUFjLENBQUNLLGNBQWYsQ0FDdENELFdBQVcsQ0FBQ0UsT0FBWixlQUNFLG9CQUFDLGFBQUQ7QUFBZSxPQUFLLEVBQUV6TDtBQUF0QixnQkFDRSxvQkFBQyxTQUFELE9BREYsQ0FERixDQURzQyxDQUF4Qzs7QUFWQWhCLE1BQU0sQ0FBQ2UsYUFBUCxDQWtCZ0IyTCxTQUFELElBQWU7QUFDNUJSLFlBQVUsQ0FBRVMsSUFBRCxJQUFVO0FBQ25CLFVBQU1KLFdBQVcsR0FBRyxJQUFJSCxpQkFBSixFQUFwQjtBQUNBTyxRQUFJLENBQUNDLHFCQUFMLENBQTJCRixTQUEzQixFQUFzQ0osY0FBYyxDQUFDQyxXQUFELENBQXBEO0FBQ0FJLFFBQUksQ0FBQ0UsWUFBTCwwQ0FBa0ROLFdBQVcsQ0FBQzFCLFFBQVosRUFBbEQ7QUFDRCxHQUpTLENBQVY7QUFLRCxDQXhCRCxFOzs7Ozs7Ozs7OztBQ0FBN0ssTUFBTSxDQUFDOE0sTUFBUCxDQUFjO0FBQUNDLEtBQUcsRUFBQyxNQUFJQSxHQUFUO0FBQWEzRCxVQUFRLEVBQUMsTUFBSUE7QUFBMUIsQ0FBZDtBQUFtRCxJQUFJNEQsR0FBSjtBQUFRaE4sTUFBTSxDQUFDQyxJQUFQLENBQVksT0FBWixFQUFvQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDNk0sT0FBRyxHQUFDN00sQ0FBSjtBQUFNOztBQUFsQixDQUFwQixFQUF3QyxDQUF4QztBQUdwRCxNQUFNNE0sR0FBRyxHQUFHO0FBQ2pCRSxPQUFLLEVBQUVELEdBQUcsQ0FBQ0QsR0FBSixDQUFRRSxLQUFSLElBQWlCO0FBRFAsQ0FBWjtBQUlBLE1BQU03RCxRQUFRLEdBQUc7QUFDdEJJLFFBQU0sRUFBRXdELEdBQUcsQ0FBQzVELFFBQUosQ0FBYUksTUFEQztBQUV0QkMsY0FBWSxFQUFFdUQsR0FBRyxDQUFDNUQsUUFBSixDQUFhSyxZQUZMO0FBR3RCQyxvQkFBa0IsRUFBRXNELEdBQUcsQ0FBQzVELFFBQUosQ0FBYU0sa0JBSFg7QUFJdEJDLFlBQVUsRUFBRXFELEdBQUcsQ0FBQ3JELFVBQUosS0FBbUJ1RCxTQUFuQixHQUErQixJQUEvQixHQUFzQ0YsR0FBRyxDQUFDNUQsUUFBSixDQUFhTztBQUp6QyxDQUFqQjtBQVBQM0osTUFBTSxDQUFDZSxhQUFQLENBY2U7QUFBRWdNLEtBQUY7QUFBTzNEO0FBQVAsQ0FkZixFOzs7Ozs7Ozs7OztBQ0FBcEosTUFBTSxDQUFDZSxhQUFQLENBQWU7QUFDYjJELFFBQU0sRUFBRTtBQURLLENBQWYsRTs7Ozs7Ozs7Ozs7QUNBQTFFLE1BQU0sQ0FBQzhNLE1BQVAsQ0FBYztBQUFDQyxLQUFHLEVBQUMsTUFBSUEsR0FBVDtBQUFhdkcsV0FBUyxFQUFDLE1BQUlBLFNBQTNCO0FBQXFDNEMsVUFBUSxFQUFDLE1BQUlBO0FBQWxELENBQWQ7QUFBQSxNQUFNO0FBQ0orRCxnQkFESTtBQUVKQyxpQkFGSTtBQUdKQyxvQkFISTtBQUlKQyxXQUpJO0FBS0pDLGlCQUxJO0FBTUpDLHVCQU5JO0FBT0pDLDZCQVBJO0FBUUpDO0FBUkksSUFTRkMsT0FBTyxDQUFDQyxHQVRaO0FBV08sTUFBTWIsR0FBRyxHQUFHO0FBQ2pCRSxPQUFLLEVBQUVLO0FBRFUsQ0FBWjtBQUlBLE1BQU05RyxTQUFTLEdBQUc7QUFDdkJXLE1BQUksRUFBRWdHLGNBRGlCO0FBRXZCL0YsT0FBSyxFQUFFZ0csZUFGZ0I7QUFHdkIvRixVQUFRLEVBQUVnRztBQUhhLENBQWxCO0FBTUEsTUFBTWpFLFFBQVEsR0FBRztBQUN0QkksUUFBTSxFQUFFK0QsZUFEYztBQUV0QjlELGNBQVksRUFBRStELHFCQUZRO0FBR3RCOUQsb0JBQWtCLEVBQUUrRCwyQkFIRTtBQUl0QjlELFlBQVUsRUFBRStEO0FBSlUsQ0FBakI7QUFyQlAxTixNQUFNLENBQUNlLGFBQVAsQ0E0QmU7QUFBRXlGLFdBQUY7QUFBYXVHLEtBQWI7QUFBa0IzRDtBQUFsQixDQTVCZixFOzs7Ozs7Ozs7OztBQ0FBcEosTUFBTSxDQUFDZSxhQUFQLENBQWU7QUFDYmlELGlCQUFlLEVBQUUsaUJBREo7QUFFYnFCLHVCQUFxQixFQUFFLHVCQUZWO0FBR2JLLHFCQUFtQixFQUFFLHFCQUhSO0FBSWJHLG9CQUFrQixFQUFFO0FBSlAsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBN0YsTUFBTSxDQUFDOE0sTUFBUCxDQUFjO0FBQUNoSCxzQkFBb0IsRUFBQyxNQUFJQTtBQUExQixDQUFkO0FBQStELElBQUkrSCxPQUFKO0FBQVk3TixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDNE4sU0FBTyxDQUFDMU4sQ0FBRCxFQUFHO0FBQUMwTixXQUFPLEdBQUMxTixDQUFSO0FBQVU7O0FBQXRCLENBQTdCLEVBQXFELENBQXJEO0FBQXdELElBQUkyTixVQUFKO0FBQWU5TixNQUFNLENBQUNDLElBQVAsQ0FBWSxNQUFaLEVBQW1CO0FBQUM2TixZQUFVLENBQUMzTixDQUFELEVBQUc7QUFBQzJOLGNBQVUsR0FBQzNOLENBQVg7QUFBYTs7QUFBNUIsQ0FBbkIsRUFBaUQsQ0FBakQ7O0FBRzNJLE1BQU0yRixvQkFBb0IsR0FBSWlJLEtBQUQsSUFBVztBQUM3QyxRQUFNQyxZQUFZLEdBQUcsRUFBckI7O0FBRUEsUUFBTUMsU0FBUyxHQUFHO0FBQUEsUUFBQztBQUFFckQ7QUFBRixLQUFEO0FBQUEsV0FBaUIsSUFBSWtELFVBQUosQ0FBZ0JJLFFBQUQsSUFBYztBQUM5REwsYUFBTyxDQUFDTSxPQUFSLENBQ1NDLFdBQVAsNkJBQXVCO0FBQ3JCSixvQkFBWSxDQUFDcEQsT0FBRCxDQUFaLEdBQXdCd0QsV0FBeEI7QUFDQUYsZ0JBQVEsQ0FBQ0csSUFBVCxlQUFvQk4sS0FBSyxDQUFDbkQsT0FBRCxDQUF6QjtBQUNELE9BSEQsQ0FERixFQUtFO0FBQUUwRCxlQUFPLEVBQUVKLFFBQVEsQ0FBQy9KO0FBQXBCLE9BTEY7QUFPRCxLQVJrQyxDQUFqQjtBQUFBLEdBQWxCOztBQVVBLFFBQU1vSyxXQUFXLEdBQUc7QUFBQSxRQUFDO0FBQUUzRDtBQUFGLEtBQUQ7QUFBQSxXQUFpQixJQUFJa0QsVUFBSixDQUFnQkksUUFBRCxJQUFjO0FBQ2hFLFVBQUlGLFlBQVksQ0FBQ3BELE9BQUQsQ0FBaEIsRUFBMkI7QUFDekJvRCxvQkFBWSxDQUFDcEQsT0FBRCxDQUFaLENBQXNCNUIsSUFBdEI7QUFDQWtGLGdCQUFRLENBQUNNLFFBQVQ7QUFDRDtBQUNGLEtBTG9DLENBQWpCO0FBQUEsR0FBcEI7O0FBT0EsU0FBTztBQUFFUCxhQUFGO0FBQWFNO0FBQWIsR0FBUDtBQUNELENBckJNOztBQUhQdk8sTUFBTSxDQUFDZSxhQUFQLENBMEJlO0FBQUUrRTtBQUFGLENBMUJmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSXZDLE1BQUo7QUFBV3ZELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3NELFFBQU0sQ0FBQ3BELENBQUQsRUFBRztBQUFDb0QsVUFBTSxHQUFDcEQsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJc08sR0FBSjtBQUFRek8sTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3NPLE9BQUcsR0FBQ3RPLENBQUo7QUFBTTs7QUFBbEIsQ0FBcEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSW1HLFFBQUo7QUFBYXRHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNtRyxZQUFRLEdBQUNuRyxDQUFUO0FBQVc7O0FBQXZCLENBQXpDLEVBQWtFLENBQWxFO0FBQXFFLElBQUl1TyxPQUFKO0FBQVkxTyxNQUFNLENBQUNDLElBQVAsQ0FBWSwyQkFBWixFQUF3QztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDdU8sV0FBTyxHQUFDdk8sQ0FBUjtBQUFVOztBQUF0QixDQUF4QyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJd08sT0FBSjtBQUFZM08sTUFBTSxDQUFDQyxJQUFQLENBQVksMkJBQVosRUFBd0M7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3dPLFdBQU8sR0FBQ3hPLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSTJJLFFBQUo7QUFBYTlJLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUMySSxZQUFRLEdBQUMzSSxDQUFUO0FBQVc7O0FBQXZCLENBQXpDLEVBQWtFLENBQWxFO0FBQXFFLElBQUl5TyxNQUFKO0FBQVc1TyxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDeU8sVUFBTSxHQUFDek8sQ0FBUDtBQUFTOztBQUFyQixDQUF2QyxFQUE4RCxDQUE5RDtBQVFoZG9ELE1BQU0sQ0FBQ2dJLE9BQVAsQ0FBZSxNQUFNO0FBQ25Ca0QsS0FBRyxDQUFDLGVBQUQsQ0FBSDtBQUNBbkksVUFBUSxDQUFDWSxlQUFUO0FBQ0FaLFVBQVEsQ0FBQ0csWUFBVDtBQUNBbEQsUUFBTSxDQUFDc0wsT0FBUCxDQUFlSCxPQUFmO0FBQ0E1RixVQUFRLENBQUN5QyxPQUFUO0FBQ0FvRCxTQUFPO0FBQ1BDLFFBQU07QUFDUCxDQVJELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyB3aXRoU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xuaW1wb3J0IHsgeWVsbG93IH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvY29sb3JzJztcblxuY29uc3QgUHJlbG9hZGVyID0gKHsgY2xhc3NlcyB9KSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzLm92ZXJsYXl9PlxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzLmNpcmN1bGFyfT4gPC9kaXY+XG4gIDwvZGl2PlxuKTtcblxuUHJlbG9hZGVyLnByb3BUeXBlcyA9IHtcbiAgY2xhc3NlczogUHJvcFR5cGVzLm9iamVjdE9mKFByb3BUeXBlcy5zdHJpbmcpLmlzUmVxdWlyZWQsXG59O1xuXG5leHBvcnQgZGVmYXVsdCB3aXRoU3R5bGVzKCh0aGVtZSkgPT4gKHtcbiAgb3ZlcmxheToge1xuICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgIHRvcDogMCxcbiAgICBsZWZ0OiAwLFxuICAgIHdpZHRoOiAnMTAwJScsXG4gICAgaGVpZ2h0OiAnMTAwJScsXG4gICAgekluZGV4OiAxMTAwLFxuICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoNDgsIDQ4LCA0OCwgLjcpJyxcbiAgICB0cmFuc2l0aW9uOiAnMC41cyBsaW5lYXIgYWxsJyxcbiAgfSxcbiAgY2lyY3VsYXI6IHtcbiAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgIGxlZnQ6ICc1MCUnLFxuICAgIHRvcDogJzUwJScsXG4gICAgd2lkdGg6IDEwMCxcbiAgICBoZWlnaHQ6IDEwMCxcbiAgICBtYXJnaW46ICctNzVweCAwIDAgLTc1cHgnLFxuICAgIGJvcmRlclJhZGl1czogJzUwJScsXG4gICAgYm9yZGVyOiAnM3B4IHNvbGlkIHRyYW5zcGFyZW50JyxcbiAgICBhbmltYXRpb246ICckc3BpbiAycyBsaW5lYXIgaW5maW5pdGUnLFxuICAgIGJvcmRlclRvcENvbG9yOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubWFpbixcbiAgICAnJjpiZWZvcmUnOiB7XG4gICAgICBjb250ZW50OiAnXCJcIicsXG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXG4gICAgICBib3JkZXI6ICczcHggc29saWQgdHJhbnNwYXJlbnQnLFxuICAgICAgYW5pbWF0aW9uOiAnJHNwaW4gM3MgbGluZWFyIGluZmluaXRlJyxcbiAgICAgIGJvcmRlclRvcENvbG9yOiB0aGVtZS5wYWxldHRlLnNlY29uZGFyeS5tYWluLFxuICAgICAgdG9wOiA1LFxuICAgICAgbGVmdDogNSxcbiAgICAgIHJpZ2h0OiA1LFxuICAgICAgYm90dG9tOiA1LFxuICAgIH0sXG4gICAgJyY6YWZ0ZXInOiB7XG4gICAgICBjb250ZW50OiAnXCJcIicsXG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXG4gICAgICBib3JkZXI6ICczcHggc29saWQgdHJhbnNwYXJlbnQnLFxuICAgICAgYW5pbWF0aW9uOiAnJHNwaW4gMS41cyBsaW5lYXIgaW5maW5pdGUnLFxuICAgICAgYm9yZGVyVG9wQ29sb3I6IHllbGxvdy5BNDAwLFxuICAgICAgdG9wOiAxNSxcbiAgICAgIGxlZnQ6IDE1LFxuICAgICAgcmlnaHQ6IDE1LFxuICAgICAgYm90dG9tOiAxNSxcbiAgICB9LFxuICB9LFxuICAnQGtleWZyYW1lcyBzcGluJzoge1xuICAgICcwJSc6IHtcbiAgICAgIHRyYW5zZm9ybTogJ3JvdGF0ZSgwZGVnKScsXG4gICAgfSxcbiAgICAnMTAwJSc6IHtcbiAgICAgIHRyYW5zZm9ybTogJ3JvdGF0ZSgzNjBkZWcpJyxcbiAgICB9LFxuICB9LFxufSkpKFByZWxvYWRlcik7XG4iLCIvLyBBIHRoZW1lIHdpdGggY3VzdG9tIHByaW1hcnkgYW5kIHNlY29uZGFyeSBjb2xvci5cbi8vIEl0J3Mgb3B0aW9uYWwuXG4vLyBodHRwczovL21hdGVyaWFsLmlvL3Rvb2xzL2NvbG9yLyMhLz92aWV3LmxlZnQ9MSZ2aWV3LnJpZ2h0PTAmcHJpbWFyeS5jb2xvcj0xQTIzN0Umc2Vjb25kYXJ5LmNvbG9yPUQ4NDMxNSZwcmltYXJ5LnRleHQuY29sb3I9RkFGQUZBJnNlY29uZGFyeS50ZXh0LmNvbG9yPUZBRkFGQVxuaW1wb3J0IHsgZGVlcE9yYW5nZSwgaW5kaWdvIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvY29sb3JzJztcbmltcG9ydCB7IGNyZWF0ZU11aVRoZW1lIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcblxuY29uc3QgdGhlbWUgPSBjcmVhdGVNdWlUaGVtZSh7XG4gIHBhbGV0dGU6IHtcbiAgICBwcmltYXJ5OiBpbmRpZ28sXG4gICAgc2Vjb25kYXJ5OiBkZWVwT3JhbmdlLFxuICAgIHR5cGU6ICdkYXJrJyxcbiAgfSxcbiAgdHlwb2dyYXBoeToge1xuICAgIGZvbnRGYW1pbHk6ICdSb2JvdG8nLFxuICAgIGZvbnRTaXplOiAxNCxcbiAgICBmb250V2VpZ2h0OiAzMDAsXG4gICAgaDE6IHtcbiAgICAgIGZvbnRTaXplOiAnMy41cmVtJyxcbiAgICB9LFxuICAgIGgyOiB7XG4gICAgICBmb250U2l6ZTogJzNyZW0nLFxuICAgIH0sXG4gICAgaDM6IHtcbiAgICAgIGZvbnRTaXplOiAnMi41cmVtJyxcbiAgICB9LFxuICAgIGg0OiB7XG4gICAgICBmb250U2l6ZTogJzJyZW0nLFxuICAgIH0sXG4gICAgaDU6IHtcbiAgICAgIGZvbnRTaXplOiAnMS41cmVtJyxcbiAgICB9LFxuICAgIGg2OiB7XG4gICAgICBmb250U2l6ZTogJzFyZW0nLFxuICAgIH0sXG4gIH0sXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgdGhlbWU7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaW1wb3J0IERldmljZXMgZnJvbSAnLi4vY29sbGVjdGlvbnMvZGV2aWNlcyc7XG5cbmltcG9ydCBNRVRIT0RTIGZyb20gJy4uL21ldGhvZHMnO1xuaW1wb3J0IERFVklDRVMgZnJvbSAnLi4vZGV2aWNlcyc7XG5cbmNvbnN0IGRpc2NvdmVyID0gKCkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICB0cnkge1xuICAgIE1ldGVvci5jYWxsKE1FVEhPRFMuRElTQ09WRVJfQ0FNRVJBLCAoZXJyLCByZXNwb25zZSkgPT4ge1xuICAgICAgaWYgKGVycikgcmV0dXJuIHJlamVjdChlcnIpO1xuICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmVqZWN0KGVycm9yKTtcbiAgfVxufSk7XG5cbmNvbnN0IGFkZCA9IGFzeW5jIChwYXJhbXMpID0+IHtcbiAgY29uc3QgeyBob3N0bmFtZSwgcG9ydCB9ID0gcGFyYW1zLmRldGFpbHM7XG4gIHJldHVybiBEZXZpY2VzLmluc2VydCh7XG4gICAgLi4ucGFyYW1zLFxuICAgIGRldGFpbHM6IHsgaG9zdG5hbWUsIHBvcnQgfSxcbiAgICB0eXBlOiBERVZJQ0VTLkNBTUVSQSxcbiAgICBvd25lcjogTWV0ZW9yLnVzZXJJZCgpLFxuICB9KTtcbn07XG5cbmNvbnN0IGVkaXQgPSBhc3luYyAoeyBfaWQsIGxhYmVsLCB1c2VybmFtZSwgcGFzc3dvcmQgfSkgPT4gKFxuICBEZXZpY2VzLnVwZGF0ZSh7IF9pZCB9LCB7ICRzZXQ6IHsgbGFiZWwsIHVzZXJuYW1lLCBwYXNzd29yZCB9IH0pXG4pO1xuXG4vLyBjb25zdCBzdGFydFJlY29yZCA9IChpZCwgbmFtZSwgdXJpKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4vLyAgIE1ldGVvci5jYWxsKE1FVEhPRFMuQ0FNRVJBX1JFQ09SRF9TVEFSVCwgeyBpZCwgbmFtZSwgdXJpIH0sIChlcnIsIHJlc3BvbnNlKSA9PiB7XG4vLyAgICAgaWYgKGVycikgcmV0dXJuIHJlamVjdChlcnIpO1xuLy8gICAgIC8vIERldmljZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IHsgcmVjb3JkaW5nOiB0cnVlIH0gfSk7XG4vLyAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4vLyAgIH0pO1xuLy8gfSk7XG5cbi8vIGNvbnN0IHN0b3BSZWNvcmQgPSAoaWQpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbi8vICAgTWV0ZW9yLmNhbGwoTUVUSE9EUy5DQU1FUkFfUkVDT1JEX1NUT1AsIHsgaWQgfSwgKGVyciwgcmVzcG9uc2UpID0+IHtcbi8vICAgICBpZiAoZXJyKSByZXR1cm4gcmVqZWN0KGVycik7XG4vLyAgICAgLy8gRGV2aWNlcy51cGRhdGUoeyBfaWQ6IGlkIH0sIHsgJHNldDogeyByZWNvcmRpbmc6IGZhbHNlIH0gfSk7XG4vLyAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4vLyAgIH0pO1xuLy8gfSk7XG5cbmNvbnN0IGdldFN0cmVhbVVyaSA9IChob3N0bmFtZSwgcG9ydCwgdXNlcm5hbWUsIHBhc3N3b3JkKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gIE1ldGVvci5jYWxsKE1FVEhPRFMuQ0FNRVJBX0dFVF9TVFJFQU1fVVJJLCB7IGhvc3RuYW1lLCBwb3J0LCB1c2VybmFtZSwgcGFzc3dvcmQgfSwgKGVyciwgdXJpKSA9PiB7XG4gICAgaWYgKGVycikgcmV0dXJuIHJlamVjdChlcnIpO1xuICAgIHJlc29sdmUodXJpKTtcbiAgfSk7XG59KTtcblxuY29uc3Qgc3RhcnRSZWNvcmQgPSBhc3luYyAoaWQpID0+IHtcbiAgY29uc3QgeyBsYWJlbCwgZGV0YWlscywgdXNlcm5hbWUsIHBhc3N3b3JkIH0gPSBEZXZpY2VzLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuICBjb25zdCB7IGhvc3RuYW1lLCBwb3J0IH0gPSBkZXRhaWxzO1xuICBjb25zdCB1cmkgPSBhd2FpdCBnZXRTdHJlYW1VcmkoaG9zdG5hbWUsIHBvcnQsIHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gIC8vIGF3YWl0IHN0YXJ0UmVjb3JkKGlkLCBsYWJlbCwgdXJpKTtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBNZXRlb3IuY2FsbChNRVRIT0RTLkNBTUVSQV9SRUNPUkRfU1RBUlQsIHsgaWQsIG5hbWU6IGxhYmVsLCB1cmkgfSwgKGVyciwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGlmIChlcnIpIHJldHVybiByZWplY3QoZXJyKTtcbiAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgIH0pO1xuICB9KTtcbn07XG5cbmNvbnN0IHN0b3BSZWNvcmQgPSAoaWQpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgTWV0ZW9yLmNhbGwoTUVUSE9EUy5DQU1FUkFfUkVDT1JEX1NUT1AsIHsgaWQgfSwgKGVyciwgcmVzcG9uc2UpID0+IHtcbiAgICBpZiAoZXJyKSByZXR1cm4gcmVqZWN0KGVycik7XG4gICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gIH0pO1xufSk7XG5cbmV4cG9ydCBkZWZhdWx0IHsgZGlzY292ZXIsIGFkZCwgZWRpdCwgZ2V0U3RyZWFtVXJpLCBzdGFydFJlY29yZCwgc3RvcFJlY29yZCB9O1xuIiwiaW1wb3J0IERldmljZXMgZnJvbSAnLi4vY29sbGVjdGlvbnMvZGV2aWNlcyc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlQ29sbGVjdGlvbiB9IGZyb20gJy4uL3V0aWxzJztcblxuY29uc3QgZmluZCA9ICguLi5hcmdzKSA9PiBEZXZpY2VzLmZpbmQoLi4uYXJncyk7XG5cbmNvbnN0IGZldGNoID0gKC4uLmFyZ3MpID0+IGZpbmQoLi4uYXJncykuZmV0Y2goKTtcblxuY29uc3QgZmluZE9uZSA9IGFzeW5jICguLi5hcmdzKSA9PiBEZXZpY2VzLmZpbmRPbmUoLi4uYXJncyk7XG5cbmNvbnN0IGluc2VydCA9IGFzeW5jICguLi5hcmdzKSA9PiBEZXZpY2VzLmluc2VydCguLi5hcmdzKTtcblxuY29uc3QgcmVtb3ZlID0gYXN5bmMgKC4uLmFyZ3MpID0+IERldmljZXMucmVtb3ZlKC4uLmFyZ3MpO1xuXG5jb25zdCBvYnNlcnZhYmxlRGV2aWNlID0gT2JzZXJ2YWJsZUNvbGxlY3Rpb24oZmluZE9uZSk7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgZmluZCxcbiAgZmV0Y2gsXG4gIGZpbmRPbmUsXG4gIGluc2VydCxcbiAgcmVtb3ZlLFxuICBvYnNlcnZhYmxlRGV2aWNlLFxufTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGRlZmF1bHQgbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2RldmljZXMnKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgYXMgTWV0ZW9yQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5pbXBvcnQgeyBTVVBFUlVTRVIgfSBmcm9tICcuLi9lbnYnO1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIG9uQ3JlYXRlSG9vaygpIHtcbiAgICBNZXRlb3JBY2NvdW50cy5vbkNyZWF0ZVVzZXIoKG9wdGlvbnMsIHVzZXIpID0+IHtcbiAgICAgIGNvbnN0IHJvbGVzID0gWyd1c2VyJ107XG4gICAgICBpZiAob3B0aW9ucy5yb2xlID09PSAnYWRtaW4nKSByb2xlcy5wdXNoKCdhZG1pbicpO1xuICAgICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXIuX2lkLCByb2xlcywgUm9sZXMuR0xPQkFMX0dST1VQKTtcbiAgICB9KTtcbiAgfSxcblxuICBjcmVhdGVTdXBlclVzZXIoKSB7XG4gICAgaWYgKCFTVVBFUlVTRVIuTkFNRSB8fCAhU1VQRVJVU0VSLkVNQUlMIHx8ICFTVVBFUlVTRVIuUEFTU1dPUkQpIHtcbiAgICAgIGNvbnNvbGUuaW5mbygnU1VQRVJVU0VSIGVudi4gdmFycyBpcyBub3QgZGVmaW5lZC4gU2tpcC4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoTWV0ZW9yLnVzZXJzLmZpbmQoKS5jb3VudCgpKSB7XG4gICAgICBjb25zb2xlLmluZm8oJ1VzZXJzIGNvbGxlY3Rpb24gYWxyZWFkeSBleGlzdHMuIFNraXAuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdXNlcklkID0gTWV0ZW9yQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICB1c2VybmFtZTogU1VQRVJVU0VSLk5BTUUsXG4gICAgICBlbWFpbDogU1VQRVJVU0VSLkVNQUlMLFxuICAgICAgcGFzc3dvcmQ6IFNVUEVSVVNFUi5QQVNTV09SRCxcbiAgICB9KTtcbiAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcklkLCBbJ3VzZXInLCAnc3VwZXJ1c2VyJ10sIFJvbGVzLkdMT0JBTF9HUk9VUCk7XG5cbiAgICBjb25zb2xlLmluZm8oJ1N1cGVydXNlciBhY2NvdW50IGNyZWF0ZWQ6ICcsIHtcbiAgICAgIGlkOiB1c2VySWQsXG4gICAgICB1c2VybmFtZTogU1VQRVJVU0VSLk5BTUUsXG4gICAgICBlbWFpbDogU1VQRVJVU0VSLkVNQUlMLFxuICAgIH0pO1xuICB9LFxufTtcbiIsImltcG9ydCBmZm1wZWcgZnJvbSAnZmx1ZW50LWZmbXBlZyc7XG5pbXBvcnQgeyBEaXNjb3ZlcnksIENhbSB9IGZyb20gJ29udmlmJztcblxuaW1wb3J0IERldmljZXMgZnJvbSAnLi4vYXBpL2RldmljZXMnO1xuXG5jb25zdCBkaXNjb3ZlciA9ICgpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgdHJ5IHtcbiAgICBEaXNjb3ZlcnkucHJvYmUoKGVyciwgY2FtcykgPT4ge1xuICAgICAgaWYgKGVycikgdGhyb3cgbmV3IEVycm9yKGVycik7XG4gICAgICByZXNvbHZlKGNhbXMpO1xuICAgIH0pO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJlamVjdChlcnJvcik7XG4gIH1cbn0pO1xuXG5jb25zdCBnZXRTdHJlYW1VcmkgPSAoeyBob3N0bmFtZSwgcG9ydCwgdXNlcm5hbWUsIHBhc3N3b3JkID0gJycgfSkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICB0cnkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXdcbiAgICBuZXcgQ2FtKFxuICAgICAge1xuICAgICAgICBob3N0bmFtZSxcbiAgICAgICAgcG9ydCxcbiAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgIHBhc3N3b3JkLFxuICAgICAgfSxcbiAgICAgIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgaWYgKGVycikgdGhyb3cgbmV3IEVycm9yKGVycik7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1zaGFkb3dcbiAgICAgICAgdGhpcy5nZXRTdHJlYW1VcmkoeyBwcm90b2NvbDogJ1JUU1AnIH0sIChlcnIsIHN0cmVhbSkgPT4ge1xuICAgICAgICAgIGlmIChlcnIpIHRocm93IG5ldyBFcnJvcihlcnIpO1xuICAgICAgICAgIHJlc29sdmUoc3RyZWFtLnVyaSk7XG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICApO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJlamVjdChlcnJvcik7XG4gIH1cbn0pO1xuXG5jb25zdCBnZXRTdHJlYW0gPSAoc291cmNlKSA9PiBmZm1wZWcoc291cmNlLCB7IGxvZ2dlcjogY29uc29sZSB9KVxuICAubm9BdWRpbygpXG4gIC52aWRlb0NvZGVjKCdjb3B5JylcbiAgLnRvRm9ybWF0KCdtcDQnKVxuICAub3V0cHV0T3B0aW9ucyhbXG4gICAgJy1ydHNwX3RyYW5zcG9ydCcsXG4gICAgJ3RjcCcsXG5cbiAgICAnLW1vdmZsYWdzJyxcbiAgICAnZnJhZ19rZXlmcmFtZStlbXB0eV9tb292JyxcblxuICAgICctcmVzZXRfdGltZXN0YW1wcycsXG4gICAgJzEnLFxuXG4gICAgJy12c3luYycsXG4gICAgJzEnLFxuXG4gICAgJy1mbGFncycsXG4gICAgJ2dsb2JhbF9oZWFkZXInLFxuXG4gICAgJy1ic2Y6dicsXG4gICAgJ2R1bXBfZXh0cmEnLFxuICBdKTtcblxuY29uc3QgaGFuZGxlU3RyZWFtID0gYXN5bmMgKF9pZCkgPT4ge1xuICBjb25zdCB7IGRldGFpbHMsIHVzZXJuYW1lLCBwYXNzd29yZCB9ID0gYXdhaXQgRGV2aWNlcy5maW5kT25lKHsgX2lkIH0pO1xuICBjb25zdCB7IGhvc3RuYW1lLCBwb3J0IH0gPSBkZXRhaWxzO1xuICBjb25zdCBzdHJlYW1VcmkgPSBhd2FpdCBnZXRTdHJlYW1Vcmkoe1xuICAgIGhvc3RuYW1lLFxuICAgIHBvcnQsXG4gICAgdXNlcm5hbWUsXG4gICAgcGFzc3dvcmQsXG4gIH0pO1xuICByZXR1cm4gZ2V0U3RyZWFtKHN0cmVhbVVyaSk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCB7IGRpc2NvdmVyLCBnZXRTdHJlYW1VcmksIGhhbmRsZVN0cmVhbSB9O1xuIiwiaW1wb3J0IE1FVEhPRFMgZnJvbSAnLi4vbWV0aG9kcyc7XG5pbXBvcnQgQ2FtZXJhIGZyb20gJy4vY2FtZXJhJztcbmltcG9ydCBSZWNvcmRlciBmcm9tICcuL3JlY29yZGVyJztcblxuZXhwb3J0IGRlZmF1bHQge1xuICBbTUVUSE9EUy5ESVNDT1ZFUl9DQU1FUkFdOiBDYW1lcmEuZGlzY292ZXIsXG4gIFtNRVRIT0RTLkNBTUVSQV9HRVRfU1RSRUFNX1VSSV06IENhbWVyYS5nZXRTdHJlYW1VcmksXG4gIFtNRVRIT0RTLkNBTUVSQV9SRUNPUkRfU1RBUlRdOiBSZWNvcmRlci5zdGFydCxcbiAgW01FVEhPRFMuQ0FNRVJBX1JFQ09SRF9TVE9QXTogUmVjb3JkZXIuc3RvcCxcbn07XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaW1wb3J0IERldmljZXMgZnJvbSAnLi4vY29sbGVjdGlvbnMvZGV2aWNlcyc7XG5cbi8qKlxuICogWW91J3ZlIHNldCB1cCBzb21lIGRhdGEgc3Vic2NyaXB0aW9ucyB3aXRoIE1ldGVvci5wdWJsaXNoKCksIGJ1dFxuICogeW91IHN0aWxsIGhhdmUgYXV0b3B1Ymxpc2ggdHVybmVkIG9uLiBCZWNhdXNlIGF1dG9wdWJsaXNoIGlzIHN0aWxsXG4gKiBvbiwgeW91ciBNZXRlb3IucHVibGlzaCgpIGNhbGxzIHdvbid0IGhhdmUgbXVjaCBlZmZlY3QuIEFsbCBkYXRhXG4gKiB3aWxsIHN0aWxsIGJlIHNlbnQgdG8gYWxsIGNsaWVudHMuXG4gKlxuICogVHVybiBvZmYgYXV0b3B1Ymxpc2ggYnkgcmVtb3ZpbmcgdGhlIGF1dG9wdWJsaXNoIHBhY2thZ2U6XG4gKlxuICogICAkIG1ldGVvciByZW1vdmUgYXV0b3B1Ymxpc2hcbiAqXG4gKiAuLiBhbmQgbWFrZSBzdXJlIHlvdSBoYXZlIE1ldGVvci5wdWJsaXNoKCkgYW5kIE1ldGVvci5zdWJzY3JpYmUoKSBjYWxsc1xuICogZm9yIGVhY2ggY29sbGVjdGlvbiB0aGF0IHlvdSB3YW50IGNsaWVudHMgdG8gc2VlLlxuICovXG4vLyBUT0RPOiBSZW1vdmUgdGhpcyBsYXRlclxuZXhwb3J0IGRlZmF1bHQgKCkgPT4ge1xuICBNZXRlb3IucHVibGlzaCgnZGV2aWNlcycsICguLi5hcmdzKSA9PiBEZXZpY2VzLmZpbmQoLi4uYXJncykpO1xufTtcbiIsImltcG9ydCBSdHNwUmVjb3JkZXIsIHsgUmVjb3JkZXJFdmVudHMgfSBmcm9tICdydHNwLXZpZGVvLXJlY29yZGVyJztcbmltcG9ydCB7IFJFQ09SREVSIH0gZnJvbSAnLi4vY29uZmlnJztcbmltcG9ydCBERVZJQ0VTIGZyb20gJy4uL2RldmljZXMnO1xuaW1wb3J0IERldmljZXMgZnJvbSAnLi4vY29sbGVjdGlvbnMvZGV2aWNlcyc7XG5pbXBvcnQgYXBpIGZyb20gJy4uL2FwaS9jYW1lcmEnO1xuXG5jbGFzcyBSZWNvcmRlciB7XG4gIFJlZ2lzdHJ5ID0ge307XG5cbiAgZ2V0UmVjb3JkZXJJbnN0YW5jZSA9IChpZCwgdXJpLCBuYW1lKSA9PiB7XG4gICAgY29uc3QgeyBGT0xERVIsIFNFR01FTlRfVElNRSwgRElSX1NJWkVfVEhSRVNIT0xELCBBVVRPX0NMRUFSIH0gPSBSRUNPUkRFUjtcblxuICAgIGNvbnN0IHJlY29yZGVyID0gbmV3IFJ0c3BSZWNvcmRlcih1cmksIEZPTERFUiwge1xuICAgICAgdGl0bGU6IG5hbWUsXG4gICAgICBmaWxlbmFtZVBhdHRlcm46IGAlSC4lTS4lUy0ke25hbWUucmVwbGFjZSgvJS9nLCAnJSUnKX1gLFxuICAgICAgc2VnbWVudFRpbWU6IFNFR01FTlRfVElNRSxcbiAgICAgIGRpclNpemVUaHJlc2hvbGQ6IERJUl9TSVpFX1RIUkVTSE9MRCxcbiAgICAgIGF1dG9DbGVhcjogQVVUT19DTEVBUixcbiAgICB9KTtcblxuICAgIHJlY29yZGVyLm9uKFJlY29yZGVyRXZlbnRzLlNUQVJURUQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuU1RBUlRFRH07IFwiJHtuYW1lfVwiOiBgLCAuLi5hcmdzKTtcbiAgICB9KTtcblxuICAgIHJlY29yZGVyLm9uKFJlY29yZGVyRXZlbnRzLlNUT1BQRUQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuU1RPUFBFRH07IFwiJHtuYW1lfVwiOiBgLCAuLi5hcmdzKTtcbiAgICB9KTtcblxuICAgIHJlY29yZGVyLm9uKFJlY29yZGVyRXZlbnRzLlNUT1AsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuU1RPUH07IFwiJHtuYW1lfVwiOiBgLCAuLi5hcmdzKTtcbiAgICB9KTtcblxuICAgIHJlY29yZGVyLm9uKFJlY29yZGVyRXZlbnRzLlBST0dSRVNTLCAoYnVmZmVyKSA9PiB7XG4gICAgICBjb25zdCBwYXlsb2FkID0gYnVmZmVyLnRvU3RyaW5nKCk7XG4gICAgICAvLyBmcmFtZT0gIDYzOCBmcHM9IDIxIHE9LTEuMCBzaXplPU4vQSB0aW1lPTAwOjAwOjMxLjg1IGJpdHJhdGU9Ti9BIHNwZWVkPTEuMDR4XG4gICAgICAvLyBbcnRzcCBAIDB4N2Y4MmE4ODAwMDAwXSBtYXggZGVsYXkgcmVhY2hlZC5cbiAgICAgIC8vIFtydHNwIEAgMHg3ZjgyYTg4MDAwMDBdIFJUUDogbWlzc2VkIDEwMSBwYWNrZXRzXG4gICAgICBpZiAoXG4gICAgICAgIC9eXFxzKlxcW3J0c3AgQCAweFswLTlhLWZdK1xcXSBtYXggZGVsYXkgcmVhY2hlZC8udGVzdChwYXlsb2FkKVxuICAgICAgICB8fCAvXlxccypcXFtydHNwIEAgMHhbMC05YS1mXStcXF0gUlRQOiBtaXNzZWQvLnRlc3QocGF5bG9hZClcbiAgICAgICAgfHwgL15cXHMqZnJhbWU9Ly50ZXN0KHBheWxvYWQpXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc29sZS5sb2coYCAke25ldyBEYXRlKCl9OyAke1JlY29yZGVyRXZlbnRzLlBST0dSRVNTfTsgXCIke25hbWV9XCI6IGAsIHBheWxvYWQpO1xuICAgIH0pO1xuXG4gICAgcmVjb3JkZXIub24oUmVjb3JkZXJFdmVudHMuRVJST1IsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuRVJST1J9OyBcIiR7bmFtZX1cIjogYCwgLi4uYXJncyk7XG4gICAgfSk7XG5cbiAgICByZWNvcmRlci5vbihSZWNvcmRlckV2ZW50cy5TRUdNRU5UX1NUQVJURUQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuU0VHTUVOVF9TVEFSVEVEfTsgXCIke25hbWV9XCI6IGAsIC4uLmFyZ3MpO1xuICAgIH0pO1xuXG4gICAgcmVjb3JkZXIub24oUmVjb3JkZXJFdmVudHMuRElSRUNUT1JZX0NSRUFURUQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuRElSRUNUT1JZX0NSRUFURUR9OyBcIiR7bmFtZX1cIjogYCwgLi4uYXJncyk7XG4gICAgfSk7XG5cbiAgICByZWNvcmRlci5vbihSZWNvcmRlckV2ZW50cy5GSUxFX0NSRUFURUQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuRklMRV9DUkVBVEVEfTsgXCIke25hbWV9XCI6IGAsIC4uLmFyZ3MpO1xuICAgIH0pO1xuXG4gICAgcmVjb3JkZXIub24oUmVjb3JkZXJFdmVudHMuU1BBQ0VfRlVMTCwgKC4uLmFyZ3MpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKGAgJHtuZXcgRGF0ZSgpfTsgJHtSZWNvcmRlckV2ZW50cy5TUEFDRV9GVUxMfTsgXCIke25hbWV9XCI6IGAsIC4uLmFyZ3MpO1xuICAgIH0pO1xuXG4gICAgcmVjb3JkZXIub24oUmVjb3JkZXJFdmVudHMuU1BBQ0VfV0lQRUQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhgICR7bmV3IERhdGUoKX07ICR7UmVjb3JkZXJFdmVudHMuU1BBQ0VfV0lQRUR9OyBcIiR7bmFtZX1cIjogYCwgLi4uYXJncyk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gcmVjb3JkZXI7XG4gIH07XG5cbiAgc3RhcnQgPSAoeyBpZCwgbmFtZSwgdXJpIH0pID0+IHtcbiAgICBjb25zdCByZWNvcmRlciA9IHRoaXMuZ2V0UmVjb3JkZXJJbnN0YW5jZShpZCwgdXJpLCBuYW1lKTtcbiAgICByZWNvcmRlclxuICAgICAgLm9uKCdzdG9wcGVkJywgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoKSA9PiB7XG4gICAgICAgIERldmljZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IHsgcmVjb3JkaW5nOiBmYWxzZSB9IH0pO1xuICAgICAgfSkpXG4gICAgICAuc3RhcnQoKTtcbiAgICBEZXZpY2VzLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiB7IHJlY29yZGluZzogdHJ1ZSB9IH0pO1xuICAgIHRoaXMuUmVnaXN0cnlbaWRdID0gcmVjb3JkZXI7XG4gIH07XG5cbiAgc3RvcCA9ICh7IGlkIH0pID0+IHtcbiAgICBjb25zdCByZWNvcmRlciA9IHRoaXMuUmVnaXN0cnlbaWRdO1xuICAgIGlmIChyZWNvcmRlcikge1xuICAgICAgcmVjb3JkZXIuc3RvcCgpO1xuICAgIH1cbiAgICBEZXZpY2VzLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiB7IHJlY29yZGluZzogZmFsc2UgfSB9KTtcbiAgfTtcblxuICBzdGFydHVwID0gKCkgPT4ge1xuICAgIGNvbnN0IHByb21pc2VzID0gRGV2aWNlcy5maW5kKHsgdHlwZTogREVWSUNFUy5DQU1FUkEsIHJlY29yZGluZzogdHJ1ZSB9KVxuICAgICAgLmZldGNoKClcbiAgICAgIC5tYXAoYXN5bmMgKHsgX2lkLCBsYWJlbCwgZGV0YWlscywgdXNlcm5hbWUsIHBhc3N3b3JkIH0pID0+IHtcbiAgICAgICAgY29uc3QgeyBob3N0bmFtZSwgcG9ydCB9ID0gZGV0YWlscztcbiAgICAgICAgY29uc3QgdXJpID0gYXdhaXQgYXBpLmdldFN0cmVhbVVyaShob3N0bmFtZSwgcG9ydCwgdXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICAgICAgdGhpcy5zdGFydCh7IGlkOiBfaWQsIG5hbWU6IGxhYmVsLCB1cmkgfSk7XG4gICAgICB9KTtcbiAgICBQcm9taXNlLmFsbChwcm9taXNlcyk7XG4gIH07XG59XG5cbmNvbnN0IHJlY29yZGVyID0gbmV3IFJlY29yZGVyKCk7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgc3RhcnQ6IHJlY29yZGVyLnN0YXJ0LFxuICBzdG9wOiByZWNvcmRlci5zdG9wLFxuICBzdGFydHVwOiByZWNvcmRlci5zdGFydHVwLFxufTtcbiIsImltcG9ydCB7IFBpY2tlciB9IGZyb20gJ21ldGVvci9tZXRlb3JoYWNrczpwaWNrZXInO1xuaW1wb3J0IENhbWVyYSBmcm9tICcuL2NhbWVyYSc7XG5cbmV4cG9ydCBkZWZhdWx0ICgpID0+IHtcbiAgUGlja2VyLnJvdXRlKCcvY2FtZXJhLzppZCcsIChwYXJhbXMsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgaWQgfSA9IHBhcmFtcztcbiAgICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgQ2FtZXJhLmhhbmRsZVN0cmVhbShpZCk7XG5cbiAgICAgICAgc3RyZWFtLm9uKCdzdGFydCcsICguLi5hcmdzKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5pbmZvKCdGRk1QRUcgU3RyZWFtIGhhcyBzdGFydGVkOiAnLCAuLi5hcmdzKTtcbiAgICAgICAgICByZXNwb25zZS53cml0ZUhlYWQoMjAwLCB7ICdDb250ZW50LVR5cGUnOiAndmlkZW8vbXA0JyB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIHN0cmVhbS5vbihcInByb2dyZXNzXCIsICguLi5hcmdzKSA9PiBjb25zb2xlLmluZm8oXCJGRk1QRUcgU3RyZWFtIGluIHByb2dyZXNzOiBcIiwgLi4uYXJncykpO1xuICAgICAgICAvLyBzdHJlYW0ub24oXCJzdGRlcnJcIiwgKC4uLmFyZ3MpID0+IGNvbnNvbGUuZXJyb3IoJ0ZGTVBFRy5zdHJlYW0ub24oXCJzdGRlcnJcIjogJywgLi4uYXJncykpO1xuICAgICAgICAvLyBzdHJlYW0ub24oXCJlcnJvclwiLCAoLi4uYXJncykgPT4gY29uc29sZS5lcnJvcignRkZNUEVHLnN0cmVhbS5vbihcImVycm9yXCIgOiAnLCAuLi5hcmdzKSk7XG4gICAgICAgIHN0cmVhbS5vbignZXJyb3InLCAoKSA9PiB7fSk7XG4gICAgICAgIHN0cmVhbS5vbignZW5kJywgKC4uLmFyZ3MpID0+IGNvbnNvbGUuaW5mbygnRkZNUEVHIFN0cmVhbSBpcyBlbmRlZCB1cDogJywgLi4uYXJncykpO1xuXG4gICAgICAgIHN0cmVhbS5waXBlKHJlc3BvbnNlKTtcblxuICAgICAgICByZXNwb25zZS5vbigncGlwZScsICgpID0+IGNvbnNvbGUuaW5mbygnU3RhcnQgcGlwaW5nIHRvIHJlc3BvbnNlIHN0cmVhbS4nKSk7XG4gICAgICAgIHJlc3BvbnNlLm9uKCd1bnBpcGUnLCAoKSA9PiBjb25zb2xlLmluZm8oJ1N0b3AgcGlwaW5nIHRvIHJlc3BvbnNlIHN0cmVhbS4nKSk7XG4gICAgICAgIHJlc3BvbnNlLm9uKCdjbG9zZScsICgpID0+IHtcbiAgICAgICAgICBjb25zb2xlLmluZm8oJ1Jlc3BvbnNlIHN0cmVhbSBjbG9zZWQuJyk7XG4gICAgICAgICAgc3RyZWFtLmtpbGwoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJlc3BvbnNlLm9uKCdlbmQnLCAoKSA9PiBjb25zb2xlLmluZm8oJ1Jlc3BvbnNlIHN0cmVhbSBlbmRlZC4nKSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICByZXNwb25zZS5lbmQoJ0FuIGVycm9yIG9jY3VyZWQnKTtcbiAgICAgIH1cbiAgICB9KSgpO1xuICB9KTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyBvblBhZ2VMb2FkIH0gZnJvbSAnbWV0ZW9yL3NlcnZlci1yZW5kZXInO1xuXG5pbXBvcnQgUmVhY3RET01TZXJ2ZXIgZnJvbSAncmVhY3QtZG9tL3NlcnZlcic7XG5pbXBvcnQgeyBTZXJ2ZXJTdHlsZVNoZWV0cywgVGhlbWVQcm92aWRlciB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XG5cbmltcG9ydCB0aGVtZSBmcm9tICcuLi91aS90aGVtZSc7XG5pbXBvcnQgUHJlbG9hZGVyIGZyb20gJy4uL3VpL2NvbXBvbmVudHMvUHJlbG9hZGVyJztcblxuY29uc3QgZ2V0Qm9keUNvbnRlbnQgPSAoc3R5bGVTaGVldHMpID0+IFJlYWN0RE9NU2VydmVyLnJlbmRlclRvU3RyaW5nKFxuICBzdHlsZVNoZWV0cy5jb2xsZWN0KFxuICAgIDxUaGVtZVByb3ZpZGVyIHRoZW1lPXt0aGVtZX0+XG4gICAgICA8UHJlbG9hZGVyIC8+XG4gICAgPC9UaGVtZVByb3ZpZGVyPixcbiAgKSxcbik7XG5cbmV4cG9ydCBkZWZhdWx0IChlbGVtZW50SWQpID0+IHtcbiAgb25QYWdlTG9hZCgoc2luaykgPT4ge1xuICAgIGNvbnN0IHN0eWxlU2hlZXRzID0gbmV3IFNlcnZlclN0eWxlU2hlZXRzKCk7XG4gICAgc2luay5yZW5kZXJJbnRvRWxlbWVudEJ5SWQoZWxlbWVudElkLCBnZXRCb2R5Q29udGVudChzdHlsZVNoZWV0cykpO1xuICAgIHNpbmsuYXBwZW5kVG9IZWFkKGA8c3R5bGUgaWQ9XCIjanNzLXNlcnZlci1zaWRlXCI+JHtzdHlsZVNoZWV0cy50b1N0cmluZygpfTwvc3R5bGU+YCk7XG4gIH0pO1xufTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGltcG9ydC9uby1uYW1lZC1hcy1kZWZhdWx0LW1lbWJlciAqL1xuaW1wb3J0IEVOViBmcm9tICcuL2Vudic7XG5cbmV4cG9ydCBjb25zdCBBUFAgPSB7XG4gIFRJVExFOiBFTlYuQVBQLlRJVExFIHx8ICdEdW1iIEhvbWUnLFxufTtcblxuZXhwb3J0IGNvbnN0IFJFQ09SREVSID0ge1xuICBGT0xERVI6IEVOVi5SRUNPUkRFUi5GT0xERVIsXG4gIFNFR01FTlRfVElNRTogRU5WLlJFQ09SREVSLlNFR01FTlRfVElNRSxcbiAgRElSX1NJWkVfVEhSRVNIT0xEOiBFTlYuUkVDT1JERVIuRElSX1NJWkVfVEhSRVNIT0xELFxuICBBVVRPX0NMRUFSOiBFTlYuQVVUT19DTEVBUiA9PT0gdW5kZWZpbmVkID8gdHJ1ZSA6IEVOVi5SRUNPUkRFUi5BVVRPX0NMRUFSLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgeyBBUFAsIFJFQ09SREVSIH07XG4iLCJleHBvcnQgZGVmYXVsdCB7XG4gIENBTUVSQTogJ0NBTUVSQScsXG59O1xuIiwiY29uc3Qge1xuICBTVVBFUlVTRVJfTkFNRSxcbiAgU1VQRVJVU0VSX0VNQUlMLFxuICBTVVBFUlVTRVJfUEFTU1dPUkQsXG4gIEFQUF9USVRMRSxcbiAgUkVDT1JERVJfRk9MREVSLFxuICBSRUNPUkRFUl9TRUdNRU5UX1RJTUUsXG4gIFJFQ09SREVSX0RJUl9TSVpFX1RIUkVTSE9MRCxcbiAgUkVDT1JERVJfQVVUT19DTEVBUixcbn0gPSBwcm9jZXNzLmVudjtcblxuZXhwb3J0IGNvbnN0IEFQUCA9IHtcbiAgVElUTEU6IEFQUF9USVRMRSxcbn07XG5cbmV4cG9ydCBjb25zdCBTVVBFUlVTRVIgPSB7XG4gIE5BTUU6IFNVUEVSVVNFUl9OQU1FLFxuICBFTUFJTDogU1VQRVJVU0VSX0VNQUlMLFxuICBQQVNTV09SRDogU1VQRVJVU0VSX1BBU1NXT1JELFxufTtcblxuZXhwb3J0IGNvbnN0IFJFQ09SREVSID0ge1xuICBGT0xERVI6IFJFQ09SREVSX0ZPTERFUixcbiAgU0VHTUVOVF9USU1FOiBSRUNPUkRFUl9TRUdNRU5UX1RJTUUsXG4gIERJUl9TSVpFX1RIUkVTSE9MRDogUkVDT1JERVJfRElSX1NJWkVfVEhSRVNIT0xELFxuICBBVVRPX0NMRUFSOiBSRUNPUkRFUl9BVVRPX0NMRUFSLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgeyBTVVBFUlVTRVIsIEFQUCwgUkVDT1JERVIgfTtcbiIsImV4cG9ydCBkZWZhdWx0IHtcbiAgRElTQ09WRVJfQ0FNRVJBOiAnRElTQ09WRVJfQ0FNRVJBJyxcbiAgQ0FNRVJBX0dFVF9TVFJFQU1fVVJJOiAnQ0FNRVJBX0dFVF9TVFJFQU1fVVJJJyxcbiAgQ0FNRVJBX1JFQ09SRF9TVEFSVDogJ0NBTUVSQV9SRUNPUkRfU1RBUlQnLFxuICBDQU1FUkFfUkVDT1JEX1NUT1A6ICdDQU1FUkFfUkVDT1JEX1NUT1AnLFxufTtcbiIsImltcG9ydCB7IFRyYWNrZXIgfSBmcm9tICdtZXRlb3IvdHJhY2tlcic7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5cbmV4cG9ydCBjb25zdCBPYnNlcnZhYmxlQ29sbGVjdGlvbiA9IChxdWVyeSkgPT4ge1xuICBjb25zdCBjb21wdXRhdGlvbnMgPSB7fTtcblxuICBjb25zdCBzdWJzY3JpYmUgPSAoeyBwYXlsb2FkIH0pID0+IG5ldyBPYnNlcnZhYmxlKChvYnNlcnZlcikgPT4ge1xuICAgIFRyYWNrZXIuYXV0b3J1bihcbiAgICAgIGFzeW5jIChjb21wdXRhdGlvbikgPT4ge1xuICAgICAgICBjb21wdXRhdGlvbnNbcGF5bG9hZF0gPSBjb21wdXRhdGlvbjtcbiAgICAgICAgb2JzZXJ2ZXIubmV4dChhd2FpdCBxdWVyeShwYXlsb2FkKSk7XG4gICAgICB9LFxuICAgICAgeyBvbkVycm9yOiBvYnNlcnZlci5lcnJvciB9LFxuICAgICk7XG4gIH0pO1xuXG4gIGNvbnN0IHVuc3Vic2NyaWJlID0gKHsgcGF5bG9hZCB9KSA9PiBuZXcgT2JzZXJ2YWJsZSgob2JzZXJ2ZXIpID0+IHtcbiAgICBpZiAoY29tcHV0YXRpb25zW3BheWxvYWRdKSB7XG4gICAgICBjb21wdXRhdGlvbnNbcGF5bG9hZF0uc3RvcCgpO1xuICAgICAgb2JzZXJ2ZXIuY29tcGxldGUoKTtcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiB7IHN1YnNjcmliZSwgdW5zdWJzY3JpYmUgfTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IHsgT2JzZXJ2YWJsZUNvbGxlY3Rpb24gfTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IFNTUiBmcm9tICcuLi9pbXBvcnRzL3NlcnZlci9zc3InO1xuaW1wb3J0IEFjY291bnRzIGZyb20gJy4uL2ltcG9ydHMvc2VydmVyL2FjY291bnRzJztcbmltcG9ydCBNZXRob2RzIGZyb20gJy4uL2ltcG9ydHMvc2VydmVyL21ldGhvZHMnO1xuaW1wb3J0IFB1Ymxpc2ggZnJvbSAnLi4vaW1wb3J0cy9zZXJ2ZXIvcHVibGlzaCc7XG5pbXBvcnQgUmVjb3JkZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2ZXIvcmVjb3JkZXInO1xuaW1wb3J0IFJvdXRlcyBmcm9tICcuLi9pbXBvcnRzL3NlcnZlci9yb3V0ZXMnO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIFNTUigndmlld3BvcnQtcm9vdCcpO1xuICBBY2NvdW50cy5jcmVhdGVTdXBlclVzZXIoKTtcbiAgQWNjb3VudHMub25DcmVhdGVIb29rKCk7XG4gIE1ldGVvci5tZXRob2RzKE1ldGhvZHMpO1xuICBSZWNvcmRlci5zdGFydHVwKCk7XG4gIFB1Ymxpc2goKTtcbiAgUm91dGVzKCk7XG59KTtcbiJdfQ==
