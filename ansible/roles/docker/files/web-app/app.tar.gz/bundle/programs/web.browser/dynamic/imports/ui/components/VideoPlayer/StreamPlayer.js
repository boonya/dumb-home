function module(e,t,l){let n,a,u;function d(e){return a.createElement(u,n({preload:"none",autoPlay:!0,type:"video/mp4"},e))}l.link("@babel/runtime/helpers/extends",{default(e){n=e}},0),l.export({default:()=>d}),l.link("react",{default(e){a=e}},0),l.link(".",{default(e){u=e}},1)}

